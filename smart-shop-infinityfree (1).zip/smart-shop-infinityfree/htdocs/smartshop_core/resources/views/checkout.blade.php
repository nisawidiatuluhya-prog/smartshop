@extends('layouts.app')
@section('title', 'Checkout')

@section('content')
<div class="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8" x-data="checkoutPage(@js($profile))">
    <h1 class="mb-5 text-2xl font-bold">Checkout</h1>

    <div x-show="$store.cart.lines.length === 0" x-cloak class="card p-12 text-center">
        <p class="font-semibold">Tidak ada barang untuk di-checkout</p>
        <a href="{{ route('shop') }}" class="btn-primary mt-4">Belanja dulu</a>
    </div>

    <form x-ref="form" method="POST" action="{{ route('checkout.store') }}" enctype="multipart/form-data"
          x-show="$store.cart.lines.length > 0" x-cloak @submit.prevent="submit()" novalidate class="grid gap-6 lg:grid-cols-[1fr_22rem]">
        @csrf
        <input type="hidden" name="items" x-ref="items">
        @if ($errors->any())
            <div class="rounded-xl bg-sale-100 p-4 text-sm text-sale-600 lg:col-span-2" role="alert">
                <p class="font-semibold">Pesanan belum bisa dibuat:</p>
                <ul class="mt-1 list-disc pl-5">@foreach ($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
            </div>
        @endif
        <div class="space-y-6">
            {{-- Alamat --}}
            <section class="card space-y-4 p-5">
                <h2 class="font-semibold">Alamat pengiriman</h2>
                <div>
                    <label class="label" for="nama">Nama penerima</label>
                    <input id="nama" name="nama" x-model="f.nama" autocomplete="name" :class="err.nama && '!border-sale-500'">
                    <p class="field-error" x-text="err.nama" x-show="err.nama"></p>
                </div>
                <div>
                    <label class="label" for="telp">Nomor telepon</label>
                    <input id="telp" name="telp" x-model="f.telp" type="tel" placeholder="081234567890" autocomplete="tel" :class="err.telp && '!border-sale-500'">
                    <p class="field-error" x-text="err.telp" x-show="err.telp"></p>
                </div>
                <div>
                    <label class="label" for="alamat">Alamat lengkap</label>
                    <textarea id="alamat" name="alamat" x-model="f.alamat" rows="3" placeholder="Jalan, nomor rumah, kelurahan, kecamatan, kota, kode pos" :class="err.alamat && '!border-sale-500'"></textarea>
                    <p class="field-error" x-text="err.alamat" x-show="err.alamat"></p>
                </div>
            </section>

            {{-- Kurir --}}
            <section class="card p-5">
                <h2 class="mb-3 font-semibold">Pilih kurir</h2>
                <div class="grid gap-3 sm:grid-cols-3">
                    @foreach ($couriers as $c)
                        <label class="cursor-pointer rounded-xl border p-3 text-sm transition" :class="f.kurir === '{{ $c['kode'] }}' ? 'border-ink-900 bg-ink-50' : 'border-ink-200'">
                            <input type="radio" name="kurir" class="sr-only" value="{{ $c['kode'] }}" x-model="f.kurir">
                            <span class="block font-semibold">{{ $c['nama'] }}</span>
                            <span class="block text-ink-500">{{ $c['estimasi'] }}</span>
                            <span class="mt-1 block font-bold">{{ rupiah($c['tarif']) }}</span>
                        </label>
                    @endforeach
                </div>
            </section>

            {{-- Metode bayar --}}
            <section class="card p-5">
                <h2 class="mb-3 font-semibold">Metode pembayaran</h2>
                <div class="grid gap-3 sm:grid-cols-2">
                    <label class="cursor-pointer rounded-xl border p-3 text-sm transition" :class="f.metode === 'COD' ? 'border-ink-900 bg-ink-50' : 'border-ink-200'">
                        <input type="radio" name="metode" class="sr-only" value="COD" x-model="f.metode">
                        <span class="block font-semibold">COD (bayar di tempat)</span>
                        <span class="block text-ink-500">Bayar tunai ke kurir. Pesanan langsung diproses.</span>
                    </label>
                    <label class="cursor-pointer rounded-xl border p-3 text-sm transition" :class="f.metode === 'Transfer' ? 'border-ink-900 bg-ink-50' : 'border-ink-200'">
                        <input type="radio" name="metode" class="sr-only" value="Transfer" x-model="f.metode">
                        <span class="block font-semibold">Transfer bank</span>
                        <span class="block text-ink-500">Unggah bukti bayar. Menunggu verifikasi admin.</span>
                    </label>
                </div>

                <div x-show="f.metode === 'Transfer'" x-cloak x-transition class="mt-4 space-y-4 rounded-xl bg-accent-50 p-4">
                    <div class="text-sm">
                        <p class="text-ink-600">Transfer ke rekening toko:</p>
                        <p class="mt-1 text-lg font-bold tracking-wide">{{ $rekening['bank'] }} &middot; {{ $rekening['nomor'] }}</p>
                        <p class="text-ink-600">a.n. {{ $rekening['atas_nama'] }}</p>
                        <p class="mt-1 font-semibold" x-text="'Nominal: ' + rupiah(total)"></p>
                    </div>
                    <div>
                        <label class="label" for="bukti">Unggah bukti pembayaran</label>
                        <input id="bukti" name="bukti" type="file" accept="image/*" @change="pickFile($event)" class="bg-white">
                        <p class="field-error" x-text="err.bukti" x-show="err.bukti"></p>
                        <template x-if="bukti">
                            <img :src="bukti" alt="Pratinjau bukti bayar" class="mt-3 max-h-56 rounded-xl border border-ink-200 bg-white">
                        </template>
                    </div>
                </div>
            </section>
        </div>

        {{-- Ringkasan --}}
        <aside class="card h-fit space-y-3 p-5 lg:sticky lg:top-36">
            <h2 class="font-semibold">Ringkasan pesanan</h2>
            <ul class="max-h-56 space-y-2 overflow-y-auto text-sm">
                <template x-for="l in $store.cart.lines" :key="l.id_produk">
                    <li class="flex justify-between gap-3">
                        <span class="min-w-0 truncate"><span x-text="l.qty"></span>x <span x-text="l.nama_produk"></span></span>
                        <span class="shrink-0" x-text="rupiah(l.harga_final * l.qty)"></span>
                    </li>
                </template>
            </ul>
            <hr class="border-ink-100">
            <div class="flex justify-between text-sm"><span class="text-ink-500">Subtotal</span><span x-text="rupiah($store.cart.subtotal)"></span></div>
            <div class="flex justify-between text-sm"><span class="text-ink-500">Ongkos kirim</span><span x-text="rupiah(ongkir)"></span></div>
            <div class="flex justify-between border-t border-ink-100 pt-3 text-lg font-bold"><span>Total</span><span x-text="rupiah(total)"></span></div>
            <p class="field-error" x-text="err.cart" x-show="err.cart"></p>
            <button type="submit" class="btn-primary w-full" :disabled="done">Buat pesanan</button>
            <a href="{{ route('keranjang') }}" class="block text-center text-sm text-ink-500 hover:text-ink-900">Kembali ke keranjang</a>
        </aside>
    </form>
</div>
@endsection
