@extends('layouts.app')
@section('title', 'Keranjang')

@section('content')
<div class="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-8" x-data>
    <h1 class="mb-5 text-2xl font-bold">Keranjang belanja</h1>

    <div x-show="$store.cart.lines.length === 0" x-cloak class="card p-12 text-center">
        <x-icon name="bag" class="mx-auto h-10 w-10 text-ink-300" />
        <p class="mt-3 font-semibold">Keranjang kamu masih kosong</p>
        <a href="{{ route('shop') }}" class="btn-primary mt-4">Mulai belanja</a>
    </div>

    <div x-show="$store.cart.lines.length > 0" x-cloak class="grid gap-6 lg:grid-cols-[1fr_20rem]">
        <ul class="space-y-3">
            <template x-for="l in $store.cart.lines" :key="l.id_produk">
                <li class="card flex gap-3 p-3 sm:gap-4 sm:p-4">
                    <a :href="'/produk/' + l.slug" class="block h-20 w-20 shrink-0 overflow-hidden rounded-xl" x-html="l.thumb"></a>
                    <div class="flex min-w-0 flex-1 flex-col justify-between gap-2">
                        <div class="flex items-start justify-between gap-2">
                            <div class="min-w-0">
                                <a :href="'/produk/' + l.slug" class="block truncate font-medium hover:underline" x-text="l.nama_produk"></a>
                                <p class="text-sm text-ink-500" x-text="rupiah(l.harga_final)"></p>
                            </div>
                            <button class="rounded-lg p-1.5 text-ink-400 hover:bg-sale-100 hover:text-sale-600" @click="$store.cart.remove(l.id_produk)" aria-label="Hapus"><x-icon name="trash" class="h-5 w-5" /></button>
                        </div>
                        <div class="flex items-center justify-between">
                            <div class="flex items-center rounded-lg border border-ink-200">
                                <button class="p-2 hover:bg-ink-100" @click="$store.cart.dec(l.id_produk)" aria-label="Kurangi"><x-icon name="minus" class="h-3.5 w-3.5" /></button>
                                <span class="w-8 text-center text-sm font-semibold" x-text="l.qty"></span>
                                <button class="p-2 hover:bg-ink-100" @click="$store.cart.inc(l.id_produk)" aria-label="Tambah"><x-icon name="plus" class="h-3.5 w-3.5" /></button>
                            </div>
                            <p class="font-bold" x-text="rupiah(l.harga_final * l.qty)"></p>
                        </div>
                    </div>
                </li>
            </template>
        </ul>

        <aside class="card h-fit space-y-3 p-5 lg:sticky lg:top-36">
            <h2 class="font-semibold">Ringkasan</h2>
            <div class="flex justify-between text-sm"><span class="text-ink-500">Jumlah barang</span><span x-text="$store.cart.count"></span></div>
            <div class="flex justify-between text-sm"><span class="text-ink-500">Subtotal</span><span class="font-semibold" x-text="rupiah($store.cart.subtotal)"></span></div>
            <p class="text-xs text-ink-400">Ongkos kirim dihitung saat checkout.</p>
            <a href="{{ route('checkout') }}" class="btn-primary w-full">Lanjut ke checkout</a>
            <a href="{{ route('shop') }}" class="btn-outline w-full">Tambah barang lain</a>
        </aside>
    </div>
</div>
@endsection
