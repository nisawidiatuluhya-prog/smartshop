{{-- Pesan sementara dari server: sukses (status) atau gagal (error) --}}
@if (session('status') || session('error'))
    <div x-data="{ show: true }" x-show="show" x-transition class="mx-auto max-w-7xl px-4 pt-4 sm:px-6">
        <div class="flex items-start justify-between gap-3 rounded-xl px-4 py-3 text-sm font-medium {{ session('error') ? 'bg-sale-100 text-sale-600' : 'bg-emerald-100 text-emerald-800' }}" role="status">
            <span>{{ session('error') ?? session('status') }}</span>
            <button @click="show = false" aria-label="Tutup"><x-icon name="x" class="h-4 w-4" /></button>
        </div>
    </div>
@endif
