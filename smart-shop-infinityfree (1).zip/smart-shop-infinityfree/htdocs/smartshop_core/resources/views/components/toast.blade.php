<div x-data x-show="$store.toast.open" x-cloak x-transition
     class="fixed bottom-24 left-1/2 z-[70] w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 rounded-xl bg-ink-900 px-4 py-3 text-center text-sm font-medium text-white shadow-lg"
     role="status" x-text="$store.toast.msg"></div>
