@props(['product'])
<article class="card group flex h-full flex-col overflow-hidden transition duration-300 hover:-translate-y-1.5 hover:border-accent-200 hover:shadow-2xl hover:shadow-accent-600/15">
    <a href="{{ route('produk.show', $product['slug']) }}" class="block p-2.5 pb-0">
        <x-product-image :product="$product" class="shine rounded-xl">
            @if ($product['diskon'] > 0)
                <span class="absolute left-2 top-2 z-10 rounded-lg bg-sale-600 px-2 py-0.5 text-xs font-bold text-white shadow-lg shadow-sale-600/40">-{{ $product['diskon'] }}%</span>
            @elseif ($product['flag_status'] === 'New Arrival')
                <span class="absolute left-2 top-2 z-10 rounded-lg bg-brand-gradient px-2 py-0.5 text-xs font-bold text-white shadow-lg shadow-fuchsia-500/40">Baru</span>
            @endif
            @if ($product['stok'] < 1)
                <span class="absolute inset-0 z-10 flex items-center justify-center bg-white/70 text-sm font-semibold">Stok habis</span>
            @endif
        </x-product-image>
    </a>
    <div class="flex flex-1 flex-col p-3.5">
        <p class="text-xs text-ink-400">{{ $product['kategori'] }}</p>
        <a href="{{ route('produk.show', $product['slug']) }}" class="mt-0.5 line-clamp-2 min-h-10 text-sm font-medium leading-5 hover:text-accent-700 sm:text-base sm:leading-5">{{ $product['nama_produk'] }}</a>
        <div class="mt-1.5 flex flex-wrap items-baseline gap-x-2">
            <span class="font-extrabold">{{ rupiah($product['harga_final']) }}</span>
            @if ($product['diskon'] > 0)
                <span class="text-xs text-ink-400 line-through">{{ rupiah($product['harga']) }}</span>
            @endif
        </div>
        <button type="button" class="btn-primary mt-3 w-full !px-3" x-data
                @click="$store.cart.add({{ $product['id_produk'] }})" {{ $product['stok'] < 1 ? 'disabled' : '' }}>
            <x-icon name="plus" class="h-4 w-4" /> Add to cart
        </button>
    </div>
</article>
