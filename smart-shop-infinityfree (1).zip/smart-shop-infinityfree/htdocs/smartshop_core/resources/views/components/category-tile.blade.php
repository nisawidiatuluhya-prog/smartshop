@props(['category', 'product' => null])
<a href="{{ route('shop', ['kategori' => $category['slug']]) }}"
   class="group relative block overflow-hidden rounded-3xl border border-ink-200/80 bg-white transition duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-accent-600/15">
    @if ($product)
        <x-product-image :product="$product" class="shine aspect-[4/3] sm:aspect-square" />
    @endif
    <div class="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-ink-900/75 via-ink-900/30 to-transparent px-4 pb-3.5 pt-10">
        <span class="text-sm font-bold text-white sm:text-base">{{ $category['nama_kategori'] }}</span>
        <span class="flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-ink-900 transition group-hover:translate-x-1 group-hover:bg-white"><x-icon name="arrow" class="h-4 w-4" /></span>
    </div>
</a>
