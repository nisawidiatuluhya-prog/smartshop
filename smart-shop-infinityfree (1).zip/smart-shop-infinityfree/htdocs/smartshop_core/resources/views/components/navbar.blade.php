@props(['categories' => []])
@php
    $kat = request('kategori');
    $u = session('smartshop.user');
    $links = [
        ['Home', route('home'), request()->routeIs('home')],
        ['Shop', route('shop'), request()->routeIs('shop') && ! $kat],
    ];
    foreach ($categories as $c) {
        $links[] = [$c['nama_kategori'], route('shop', ['kategori' => $c['slug']]), request()->routeIs('shop') && $kat === $c['slug']];
    }
@endphp
<header class="glass sticky top-0 z-40 border-b border-white/60 shadow-sm shadow-accent-600/5" x-data="{ search: false }">
    <div class="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <a href="{{ route('home') }}" class="text-lg font-extrabold tracking-wide sm:text-xl"><span class="text-brand-gradient">PRIMA</span> SMART SHOP</a>

        <form action="{{ route('shop') }}" method="GET" class="relative hidden max-w-md flex-1 md:block">
            <x-icon name="search" class="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input type="search" name="q" placeholder="Cari produk" class="!rounded-full !bg-white/80 !pl-10">
        </form>

        <div class="flex items-center gap-1">
            <button class="rounded-full p-2.5 hover:bg-accent-100 md:hidden" @click="search = !search" aria-label="Cari"><x-icon name="search" /></button>
            <a href="{{ route('keranjang') }}" class="relative rounded-full p-2.5 hover:bg-accent-100" aria-label="Keranjang">
                <x-icon name="bag" />
                <span x-data x-show="$store.cart.count > 0" x-cloak x-text="$store.cart.count" :key="$store.cart.count"
                      class="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 animate-pop items-center justify-center rounded-full bg-brand-gradient px-1 text-[11px] font-bold text-white"></span>
            </a>

            @if ($u)
                <div class="relative ml-1" x-data="{ open: false }" @click.outside="open = false" @keydown.escape.window="open = false">
                    <button @click="open = !open" class="flex items-center gap-2 rounded-full p-1 pr-3 hover:bg-accent-100" aria-label="Menu akun">
                        <span class="flex h-8 w-8 items-center justify-center rounded-full bg-brand-gradient text-sm font-bold text-white">{{ strtoupper(mb_substr($u['nama'], 0, 1)) }}</span>
                        <span class="hidden max-w-24 truncate text-sm font-medium sm:block">{{ explode(' ', $u['nama'])[0] }}</span>
                    </button>
                    <div x-show="open" x-cloak x-transition.origin.top.right class="card absolute right-0 mt-2 w-56 p-2 shadow-xl">
                        <p class="truncate px-3 py-2 text-xs text-ink-500">{{ $u['email'] }}<br><span class="font-semibold text-ink-700">{{ $u['role'] === 'Admin' ? 'Administrator' : 'Pelanggan' }}</span></p>
                        @if ($u['role'] === 'Customer')
                            <a href="{{ route('pesanan.index') }}" class="block rounded-lg px-3 py-2 text-sm hover:bg-accent-100">Pesanan saya</a>
                        @endif
                        @if ($u['role'] === 'Admin')
                            <a href="{{ route('admin.dashboard') }}" class="block rounded-lg px-3 py-2 text-sm hover:bg-accent-100">Buka dashboard admin</a>
                        @endif
                        <form method="POST" action="{{ route('logout') }}">@csrf
                            <button class="w-full rounded-lg px-3 py-2 text-left text-sm text-sale-600 hover:bg-sale-100">Keluar</button>
                        </form>
                    </div>
                </div>
            @else
                <a href="{{ route('login') }}" class="ml-1 rounded-full px-3 py-2 text-sm font-medium hover:bg-accent-100">Masuk</a>
                <a href="{{ route('register') }}" class="btn-primary hidden !rounded-full !py-2 sm:inline-flex">Daftar</a>
            @endif
        </div>
    </div>

    <form x-show="search" x-cloak x-transition action="{{ route('shop') }}" method="GET" class="border-t border-ink-100 px-4 py-3 md:hidden">
        <input type="search" name="q" placeholder="Cari produk" class="!rounded-full">
    </form>

    <nav class="border-t border-ink-100/70" aria-label="Menu utama">
        <ul class="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 text-sm sm:px-6">
            @foreach ($links as [$label, $url, $active])
                <li class="shrink-0">
                    <a href="{{ $url }}" class="block border-b-2 px-3 py-3 transition {{ $active ? 'border-accent-600 font-semibold text-accent-700' : 'border-transparent text-ink-500 hover:text-ink-900' }}">{{ $label }}</a>
                </li>
            @endforeach
        </ul>
    </nav>
</header>
