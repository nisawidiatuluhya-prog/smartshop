{{-- Widget AI melayang. Jawaban pura-pura, logika ada di resources/js/app.js (aiWidget). --}}
<div x-data="aiWidget" class="fixed bottom-4 right-4 z-50 sm:bottom-6 sm:right-6" @keydown.escape.window="open = false">
    <section x-show="open" x-cloak x-transition.origin.bottom.right
             class="mb-3 flex h-[min(32rem,calc(100vh-7rem))] w-[calc(100vw-2rem)] max-w-sm flex-col overflow-hidden rounded-2xl border border-ink-200 bg-white shadow-2xl"
             aria-label="Smart AI Assistant">
        <header class="flex items-center justify-between bg-brand-gradient px-4 py-3 text-white">
            <div class="flex items-center gap-2">
                <x-icon name="sparkles" class="h-5 w-5 animate-twinkle text-white" />
                <div>
                    <p class="text-sm font-semibold leading-none">Smart AI Assistant</p>
                    <p class="mt-1 text-[11px] text-white/80">Jawaban contoh (demo)</p>
                </div>
            </div>
            <button @click="open = false" class="rounded-lg p-1 hover:bg-white/10" aria-label="Tutup"><x-icon name="x" class="h-5 w-5" /></button>
        </header>

        <div x-ref="body" class="flex-1 space-y-3 overflow-y-auto bg-ink-50 p-4">
            <template x-for="(m, i) in messages" :key="i">
                <div :class="m.from === 'me' ? 'flex justify-end' : 'flex justify-start'">
                    <div class="max-w-[88%]">
                        <p class="rounded-2xl px-3.5 py-2 text-sm leading-relaxed"
                           :class="m.from === 'me' ? 'rounded-br-sm bg-brand-gradient text-white' : 'rounded-bl-sm border border-ink-200 bg-white'"
                           x-text="m.text"></p>
                        <div class="mt-2 space-y-2" x-show="m.picks && m.picks.length">
                            <template x-for="p in m.picks" :key="p.id_produk">
                                <div class="flex items-center gap-3 rounded-xl border border-ink-200 bg-white p-2">
                                    <a :href="'/produk/' + p.slug" class="block h-14 w-14 shrink-0 overflow-hidden rounded-lg" x-html="p.thumb"></a>
                                    <div class="min-w-0 flex-1">
                                        <a :href="'/produk/' + p.slug" class="block truncate text-sm font-medium hover:underline" x-text="p.nama_produk"></a>
                                        <p class="text-sm font-bold" x-text="rupiah(p.harga_final)"></p>
                                    </div>
                                    <button class="rounded-lg bg-ink-900 p-2 text-white hover:bg-ink-700" @click="$store.cart.add(p.id_produk)" aria-label="Tambah ke keranjang">
                                        <x-icon name="plus" class="h-4 w-4" />
                                    </button>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>
            </template>
            <div x-show="typing" class="flex gap-1 pl-2" aria-label="Mengetik">
                <span class="h-2 w-2 animate-bounce rounded-full bg-ink-300"></span>
                <span class="h-2 w-2 animate-bounce rounded-full bg-ink-300 [animation-delay:.15s]"></span>
                <span class="h-2 w-2 animate-bounce rounded-full bg-ink-300 [animation-delay:.3s]"></span>
            </div>
        </div>

        <div class="flex gap-2 overflow-x-auto border-t border-ink-100 bg-white px-3 pt-2.5">
            <template x-for="s in suggestions" :key="s">
                <button class="shrink-0 rounded-full border border-ink-200 px-3 py-1 text-xs text-ink-600 hover:border-ink-900" @click="ask(s)" x-text="s"></button>
            </template>
        </div>
        <form class="flex gap-2 bg-white p-3" @submit.prevent="ask()">
            <input x-model="input" type="text" placeholder="Tulis pertanyaan..." class="!rounded-full" aria-label="Pertanyaan">
            <button class="btn-primary !rounded-full !px-3.5" aria-label="Kirim"><x-icon name="send" class="h-4 w-4" /></button>
        </form>
    </section>

    <div class="flex justify-end">
        <button @click="open = !open"
                class="relative flex items-center gap-2 rounded-full bg-brand-gradient px-4 py-3 text-sm font-semibold text-white shadow-xl shadow-fuchsia-500/40 transition hover:-translate-y-0.5 hover:shadow-2xl sm:px-5">
            <span class="absolute inset-0 -z-10 animate-ring rounded-full bg-fuchsia-400" x-show="!open"></span>
            <x-icon name="sparkles" class="h-5 w-5" />
            <span class="hidden sm:inline" x-text="open ? 'Tutup asisten' : 'Tanya Smart AI Assistant'"></span>
            <span class="sm:hidden" x-text="open ? 'Tutup' : 'Tanya AI'"></span>
        </button>
    </div>
</div>
