{{--
  Garis waktu 4 status pesanan.
  Pakai statis : <x-status-timeline status="Diproses" />
  Pakai Alpine : <x-status-timeline expr="status" />   (ekspresi dari x-data induk)
--}}
@props(['status' => null, 'expr' => null])
@php
    $steps = ['Menunggu Verifikasi', 'Diproses', 'Dikirim', 'Selesai'];
    $cur = $expr ?? json_encode($status);
@endphp
<ol x-data="{ steps: @js($steps) }" class="grid grid-cols-4 gap-1">
    @foreach ($steps as $i => $step)
        <li class="relative flex flex-col items-center text-center">
            @if ($i > 0)
                <span class="absolute right-1/2 top-4 -z-0 h-0.5 w-full transition-colors"
                      :class="steps.indexOf({{ $cur }}) >= {{ $i }} ? 'bg-ink-900' : 'bg-ink-200'"></span>
            @endif
            <span class="relative z-10 flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold transition-colors"
                  :class="steps.indexOf({{ $cur }}) >= {{ $i }} ? 'bg-ink-900 text-white' : 'bg-ink-100 text-ink-400'">
                <template x-if="steps.indexOf({{ $cur }}) > {{ $i }}"><x-icon name="check" class="h-4 w-4" /></template>
                <template x-if="steps.indexOf({{ $cur }}) <= {{ $i }}"><span>{{ $i + 1 }}</span></template>
            </span>
            <span class="mt-2 text-[11px] leading-tight sm:text-sm"
                  :class="steps.indexOf({{ $cur }}) >= {{ $i }} ? 'font-semibold text-ink-900' : 'text-ink-400'">{{ $step }}</span>
        </li>
    @endforeach
</ol>
