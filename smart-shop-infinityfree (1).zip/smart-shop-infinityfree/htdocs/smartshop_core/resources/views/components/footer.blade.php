<footer class="glass mt-16 border-t border-white/60">
    <div class="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-4">
        <div class="md:col-span-2">
            <p class="text-lg font-extrabold tracking-wide"><span class="text-brand-gradient">PRIMA</span> SMART SHOP</p>
            <p class="mt-2 max-w-sm text-sm text-ink-500">Prima Smart Shop, pusat transaksi digital modern dengan layanan belanja pintar serba ada. Belanja fashion, kosmetik, sepatu, dan tas dengan mudah, ditemani Smart AI Assistant.</p>
        </div>
        <div>
            <p class="text-sm font-semibold">Belanja</p>
            <ul class="mt-3 space-y-2 text-sm text-ink-500">
                <li><a class="hover:text-ink-900" href="{{ route('shop') }}">Semua produk</a></li>
                <li><a class="hover:text-ink-900" href="{{ route('shop', ['flash' => 1]) }}">Flash sale</a></li>
                <li><a class="hover:text-ink-900" href="{{ route('keranjang') }}">Keranjang</a></li>
            </ul>
        </div>
        <div>
            <p class="text-sm font-semibold">Pembayaran</p>
            <ul class="mt-3 space-y-2 text-sm text-ink-500">
                <li>COD (bayar di tempat)</li>
                <li>Transfer bank</li>
                <li><a class="hover:text-ink-900" href="{{ route('admin.login') }}">Masuk admin</a></li>
            </ul>
        </div>
    </div>
    <div class="border-t border-ink-100 py-4 text-center text-xs text-ink-400">&copy; {{ date('Y') }} PRIMA SMART SHOP. Hak cipta dilindungi.</div>
</footer>
