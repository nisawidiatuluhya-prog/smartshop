@props(['label', 'value', 'hint' => null, 'icon' => null, 'tone' => 'violet'])
@php
    $tones = [
        'violet'  => 'from-violet-500 to-fuchsia-500 shadow-fuchsia-500/30',
        'emerald' => 'from-emerald-400 to-teal-500 shadow-teal-500/30',
        'amber'   => 'from-amber-400 to-orange-500 shadow-orange-500/30',
        'sky'     => 'from-sky-400 to-indigo-500 shadow-indigo-500/30',
    ];
@endphp
<div {{ $attributes->merge(['class' => 'card flex items-start justify-between gap-3 p-4 transition hover:-translate-y-0.5 hover:shadow-lg hover:shadow-accent-600/10 sm:p-5']) }}>
    <div class="min-w-0">
        <p class="text-sm text-ink-500">{{ $label }}</p>
        <p class="mt-1 text-2xl font-extrabold sm:text-3xl">{{ $value }}</p>
        @if ($hint) <p class="mt-1 text-xs text-ink-400">{{ $hint }}</p> @endif
    </div>
    @if ($icon)
        <span class="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br text-white shadow-lg {{ $tones[$tone] ?? $tones['violet'] }}">
            <x-icon :name="$icon" class="h-5 w-5" />
        </span>
    @endif
</div>
