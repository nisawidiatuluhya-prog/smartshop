{{--
  Gambar produk. Urutan prioritas:
  1) FOTO ASLI: taruh file di  public/images/produk/{slug}.jpg  (atau .jpeg/.png/.webp)
  2) kolom "gambar" produk (storage/)
  3) ILUSTRASI glossy bawaan (SVG lokal, tanpa internet)
--}}
@props(['product', 'size' => null])
@php
    $foto = null;
    foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
        if (file_exists(public_path("images/produk/{$product['slug']}.$ext"))) {
            $foto = asset("images/produk/{$product['slug']}.$ext");
            break;
        }
    }
    if (! $foto && $product['gambar']) { $foto = asset('storage/' . $product['gambar']); }

    $id = $product['id_produk'];
    [$c1, $c2] = $product['warna'];
    [$b1, $b2] = $product['latar'];
    $shape = $product['ilustrasi'];
@endphp
<div {{ $attributes->merge(['class' => 'relative aspect-square overflow-hidden']) }}>
    @if ($foto)
        <img src="{{ $foto }}" alt="{{ $product['nama_produk'] }}" class="h-full w-full object-cover transition duration-500 group-hover:scale-105" loading="lazy">
    @else
        <svg viewBox="0 0 200 200" class="h-full w-full transition duration-500 group-hover:scale-105" role="img" aria-label="{{ $product['nama_produk'] }}">
            <defs>
                <radialGradient id="bg{{ $id }}" cx=".25" cy=".2" r="1"><stop offset="0" stop-color="{{ $b1 }}"/><stop offset="1" stop-color="{{ $b2 }}"/></radialGradient>
                <linearGradient id="g{{ $id }}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{{ $c1 }}"/><stop offset="1" stop-color="{{ $c2 }}"/></linearGradient>
                <linearGradient id="s{{ $id }}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".6"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/></linearGradient>
            </defs>
            <rect width="200" height="200" fill="url(#bg{{ $id }})"/>
            <circle cx="158" cy="38" r="56" fill="#fff" opacity=".35"/>
            <circle cx="30" cy="170" r="34" fill="#fff" opacity=".22"/>
            <ellipse cx="100" cy="176" rx="56" ry="7" fill="#1e1b4b" opacity=".16"/>

            @switch($shape)
                @case('shirt')
                    <path id="b{{ $id }}" d="M64 36 L34 54 L22 100 L48 106 L56 84 V168 H144 V84 L152 106 L178 100 L166 54 L136 36 C128 58 72 58 64 36 Z" fill="url(#g{{ $id }})"/>
                    <path d="M64 36 L100 78 L136 36" fill="none" stroke="{{ $c2 }}" stroke-opacity=".55" stroke-width="3" stroke-linejoin="round"/>
                    <path d="M100 78 V168" stroke="{{ $c2 }}" stroke-opacity=".35" stroke-width="2"/>
                    @foreach ([94, 112, 130, 148] as $y) <circle cx="108" cy="{{ $y }}" r="2.6" fill="{{ $c2 }}" opacity=".6"/> @endforeach
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('tee')
                    <path id="b{{ $id }}" d="M68 34 L30 56 L42 98 L62 90 V166 H138 V90 L158 98 L170 56 L132 34 C124 54 76 54 68 34 Z" fill="url(#g{{ $id }})"/>
                    <path d="M72 36 C80 58 120 58 128 36" fill="none" stroke="{{ $c2 }}" stroke-opacity=".6" stroke-width="4"/>
                    <path d="M74 120 H126 M74 134 H110" stroke="#fff" stroke-opacity=".55" stroke-width="5" stroke-linecap="round"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('dress')
                    <path id="b{{ $id }}" d="M80 24 L74 68 C72 84 62 94 54 112 L34 172 C70 186 130 186 166 172 L146 112 C138 94 128 84 126 68 L120 24 H108 C106 40 94 40 92 24 Z" fill="url(#g{{ $id }})"/>
                    <path d="M64 92 C90 102 110 102 136 92" fill="none" stroke="{{ $c2 }}" stroke-width="7" stroke-linecap="round" opacity=".7"/>
                    @foreach ([[70,134],[96,150],[124,138],[84,166],[140,160],[106,120]] as [$x,$y])
                        <circle cx="{{ $x }}" cy="{{ $y }}" r="5" fill="#fff" opacity=".7"/><circle cx="{{ $x }}" cy="{{ $y }}" r="2" fill="#fde68a"/>
                    @endforeach
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('pants')
                    <path id="b{{ $id }}" d="M56 28 H144 L164 174 H108 L100 94 L92 174 H36 Z" fill="url(#g{{ $id }})"/>
                    <path d="M56 28 H144 L145 46 H55 Z" fill="{{ $c2 }}" opacity=".55"/>
                    <path d="M70 60 L52 170 M130 60 L148 170 M100 94 V60" stroke="#fff" stroke-opacity=".35" stroke-width="2.5"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('lipstick')
                    <path d="M86 102 V58 L100 36 L116 50 V102 Z" fill="url(#g{{ $id }})"/>
                    <path d="M94 100 V62 L100 52" stroke="#fff" stroke-opacity=".5" stroke-width="3" fill="none" stroke-linecap="round"/>
                    <rect x="76" y="100" width="48" height="16" rx="4" fill="#f5d28a"/><rect x="76" y="100" width="48" height="6" rx="3" fill="#fff" opacity=".5"/>
                    <rect x="76" y="116" width="48" height="56" rx="7" fill="#27214a"/>
                    <rect x="84" y="122" width="6" height="44" rx="3" fill="#fff" opacity=".28"/>
                    <rect x="98" y="136" width="18" height="3" rx="1.5" fill="#f5d28a" opacity=".8"/>
                    @break
                @case('serum')
                    <path d="M90 70 V46 a10 10 0 0 1 20 0 V70 Z" fill="#27214a"/>
                    <rect x="86" y="68" width="28" height="22" rx="4" fill="#f5d28a"/>
                    <rect id="b{{ $id }}" x="64" y="88" width="72" height="82" rx="20" fill="url(#g{{ $id }})"/>
                    <rect x="76" y="114" width="48" height="38" rx="7" fill="#fff" opacity=".88"/>
                    <rect x="84" y="124" width="32" height="4" rx="2" fill="{{ $c2 }}"/><rect x="84" y="134" width="22" height="4" rx="2" fill="{{ $c2 }}" opacity=".5"/>
                    <rect x="72" y="96" width="8" height="64" rx="4" fill="#fff" opacity=".4"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('tube')
                    <path id="b{{ $id }}" d="M72 58 H128 L136 150 Q136 162 124 162 H76 Q64 162 64 150 Z" fill="url(#g{{ $id }})"/>
                    <rect x="68" y="46" width="64" height="14" rx="3" fill="{{ $c2 }}"/>
                    <rect x="82" y="160" width="36" height="16" rx="5" fill="#27214a"/>
                    <circle cx="100" cy="106" r="15" fill="#fde68a"/>
                    <path d="M100 80 V84 M100 128 V132 M74 106 H78 M122 106 H126 M82 88 L85 91 M115 121 L118 124 M118 88 L115 91 M85 121 L82 124" stroke="#f59e0b" stroke-width="3" stroke-linecap="round"/>
                    <rect x="82" y="138" width="36" height="4" rx="2" fill="#fff" opacity=".8"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('compact')
                    <circle id="b{{ $id }}" cx="100" cy="106" r="62" fill="url(#g{{ $id }})"/>
                    <circle cx="100" cy="106" r="48" fill="#fff" opacity=".85"/>
                    <circle cx="100" cy="106" r="42" fill="#f1cfae"/>
                    <circle cx="100" cy="106" r="30" fill="#e6b891"/>
                    @foreach ([[88,98],[108,92],[112,114],[90,118],[100,106]] as [$x,$y]) <circle cx="{{ $x }}" cy="{{ $y }}" r="2.4" fill="#d9a07a"/> @endforeach
                    <rect x="88" y="162" width="24" height="10" rx="4" fill="{{ $c2 }}"/>
                    <path d="M54 84 A52 52 0 0 1 96 54" stroke="#fff" stroke-opacity=".8" stroke-width="5" fill="none" stroke-linecap="round"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('sneaker')
                @case('runner')
                    <path id="b{{ $id }}" d="M24 130 C24 118 32 114 44 112 L66 106 C74 90 84 72 92 64 L110 72 C116 84 128 94 144 98 C166 102 180 112 180 130 V140 H24 Z" fill="url(#g{{ $id }})"/>
                    <path d="M144 98 C166 102 180 112 180 130 H140 Z" fill="{{ $c2 }}" opacity=".18"/>
                    <path d="M58 124 C90 128 120 118 142 100" fill="none" stroke="{{ $c2 }}" stroke-width="6" stroke-linecap="round" opacity=".75"/>
                    <path d="M96 76 L106 86 M90 86 L102 96 M84 96 L96 106" stroke="#fff" stroke-width="4" stroke-linecap="round" opacity=".9"/>
                    @if ($shape === 'runner') @foreach ([[56,116],[66,122],[76,126],[148,114],[158,120]] as [$x,$y]) <circle cx="{{ $x }}" cy="{{ $y }}" r="2.4" fill="#fff" opacity=".7"/> @endforeach @endif
                    <rect x="20" y="138" width="164" height="18" rx="9" fill="{{ $shape === 'runner' ? '#fff' : '#f8fafc' }}"/>
                    <rect x="20" y="146" width="164" height="5" rx="2.5" fill="{{ $c2 }}" opacity=".35"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('slide')
                    <path d="M28 140 C28 124 48 116 72 116 H150 C172 116 180 128 180 140 C180 154 168 160 150 160 H58 C38 160 28 154 28 140 Z" fill="{{ $c2 }}"/>
                    <path d="M34 138 C40 126 56 122 74 122 H148 C166 122 174 130 176 138 C170 146 156 148 148 148 H62 C46 148 38 144 34 138 Z" fill="#fff" opacity=".28"/>
                    <path id="b{{ $id }}" d="M56 128 C62 82 138 82 146 128 L126 132 C122 108 80 108 76 132 Z" fill="url(#g{{ $id }})"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('flat')
                    <path id="b{{ $id }}" d="M28 136 C28 118 44 112 60 114 C84 120 106 112 122 98 C152 98 178 112 180 136 C180 144 174 148 166 148 H44 C34 148 28 144 28 136 Z" fill="url(#g{{ $id }})"/>
                    <path d="M60 114 C86 126 110 122 124 98" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="4" stroke-linecap="round"/>
                    <path d="M142 106 l10 -8 l0 16 z M162 106 l-10 -8 l0 16 z" fill="{{ $c2 }}" opacity=".7"/>
                    <rect x="26" y="146" width="156" height="9" rx="4.5" fill="#27214a"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('tote')
                    <path d="M68 80 C68 24 132 24 132 80" fill="none" stroke="{{ $c2 }}" stroke-width="9" stroke-linecap="round"/>
                    <path id="b{{ $id }}" d="M42 78 H158 L168 174 H32 Z" fill="url(#g{{ $id }})"/>
                    <rect x="76" y="108" width="48" height="38" rx="8" fill="#fff" opacity=".85"/>
                    <path d="M100 136 C86 126 84 118 92 116 C96 115 99 118 100 120 C101 118 104 115 108 116 C116 118 114 126 100 136 Z" fill="#fb7185"/>
                    <path d="M42 90 H158" stroke="{{ $c2 }}" stroke-opacity=".5" stroke-width="2" stroke-dasharray="5 4"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('backpack')
                    <path d="M86 52 C86 34 114 34 114 52" fill="none" stroke="{{ $c2 }}" stroke-width="7" stroke-linecap="round"/>
                    <rect id="b{{ $id }}" x="52" y="48" width="96" height="124" rx="32" fill="url(#g{{ $id }})"/>
                    <rect x="64" y="106" width="72" height="50" rx="14" fill="{{ $c2 }}" opacity=".4"/>
                    <path d="M70 98 H130" stroke="#fff" stroke-opacity=".6" stroke-width="3" stroke-dasharray="6 4" stroke-linecap="round"/>
                    <circle cx="130" cy="98" r="5" fill="#f5d28a"/>
                    <rect x="92" y="122" width="16" height="6" rx="3" fill="#fff" opacity=".7"/>
                    <path d="M54 90 C44 100 44 128 54 140 M146 90 C156 100 156 128 146 140" fill="none" stroke="{{ $c2 }}" stroke-width="7" stroke-linecap="round" opacity=".8"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @case('sling')
                    <path d="M60 74 C56 24 146 24 140 74" fill="none" stroke="{{ $c2 }}" stroke-width="7" stroke-linecap="round"/>
                    <path id="b{{ $id }}" d="M50 90 C50 78 58 72 70 72 H130 C142 72 150 78 150 90 V142 C150 154 142 160 130 160 H70 C58 160 50 154 50 142 Z" fill="url(#g{{ $id }})"/>
                    <path d="M50 90 C50 78 58 72 70 72 H130 C142 72 150 78 150 90 L100 118 Z" fill="{{ $c2 }}" opacity=".4"/>
                    <circle cx="100" cy="116" r="8" fill="#f5d28a"/><circle cx="97" cy="113" r="3" fill="#fff" opacity=".7"/>
                    <rect x="64" y="136" width="72" height="3" rx="1.5" fill="#fff" opacity=".5"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
                    @break
                @default {{-- shoulder --}}
                    <path d="M64 78 C58 22 142 22 136 78" fill="none" stroke="#f5d28a" stroke-width="5" stroke-dasharray="7 3" stroke-linecap="round"/>
                    <path id="b{{ $id }}" d="M44 94 C44 82 52 78 66 78 H134 C148 78 156 82 156 94 L164 154 C164 166 156 170 146 170 H54 C44 170 36 166 36 154 Z" fill="url(#g{{ $id }})"/>
                    <path d="M44 96 H156 L100 134 Z" fill="#000" opacity=".22"/>
                    <rect x="90" y="124" width="20" height="14" rx="4" fill="#f5d28a"/><rect x="90" y="124" width="20" height="5" rx="2.5" fill="#fff" opacity=".55"/>
                    <use href="#b{{ $id }}" fill="url(#s{{ $id }})"/>
            @endswitch
        </svg>
    @endif
    {{ $slot }}
</div>
