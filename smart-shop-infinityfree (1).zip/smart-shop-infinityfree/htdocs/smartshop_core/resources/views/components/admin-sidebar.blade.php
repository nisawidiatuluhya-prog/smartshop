@php
    $menu = [
        ['Dashboard', 'admin.dashboard', 'home', 'admin'],
        ['Manajemen produk', 'admin.produk', 'cube', 'admin/produk*'],
        ['Kelola kategori', 'admin.kategori', 'grid', 'admin/kategori*'],
        ['Pesanan', 'admin.pesanan', 'orders', 'admin/pesanan*'],
        ['Laporan penjualan', 'admin.laporan', 'chart', 'admin/laporan*'],
    ];
@endphp
<aside class="fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-ink-200 bg-white transition-transform lg:static lg:!translate-x-0"
       :class="sidebar ? 'translate-x-0' : '-translate-x-full'">
    <div class="flex h-14 items-center justify-between px-5">
        <a href="{{ route('admin.dashboard') }}" class="text-lg font-extrabold tracking-wide"><span class="text-brand-gradient">PRIMA</span> SMART SHOP</a>
        <button class="rounded-lg p-1.5 hover:bg-ink-100 lg:hidden" @click="sidebar = false" aria-label="Tutup menu"><x-icon name="x" class="h-5 w-5" /></button>
    </div>
    <nav class="flex-1 space-y-1 px-3 py-4">
        @foreach ($menu as [$label, $route, $icon, $pattern])
            @php($active = request()->is($pattern))
            <a href="{{ route($route) }}" class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition {{ $active ? 'bg-brand-gradient font-semibold text-white shadow-md shadow-fuchsia-500/30' : 'text-ink-600 hover:bg-ink-100' }}">
                <x-icon :name="$icon" class="h-5 w-5" /> {{ $label }}
            </a>
        @endforeach
        <a href="{{ route('admin.dashboard') }}#ai" class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-ink-600 transition hover:bg-ink-100">
            <x-icon name="sparkles" class="h-5 w-5" /> AI analytics
        </a>
    </nav>
    <div class="border-t border-ink-100 p-3">
        <form method="POST" action="{{ route('logout') }}">@csrf
            <button class="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-sale-600 hover:bg-sale-100"><x-icon name="logout" class="h-5 w-5" /> Keluar</button>
        </form>
    </div>
</aside>
