@extends('layouts.app')
@section('title', 'Shop')

@section('content')
<div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8" x-data="shopPage">
    <div class="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
            <h1 class="text-2xl font-bold">Shop</h1>
            <p class="text-sm text-ink-500"><span x-text="count"></span> produk ditemukan</p>
        </div>
        <div class="flex items-center gap-2">
            <button class="btn-outline lg:hidden" @click="filterOpen = !filterOpen"><x-icon name="filter" class="h-4 w-4" /> Filter</button>
            <label class="sr-only" for="sort">Urutkan</label>
            <select id="sort" x-model="sort" class="!w-auto">
                <option value="terlaris">Terlaris</option>
                <option value="terbaru">Terbaru</option>
                <option value="termurah">Harga termurah</option>
            </select>
        </div>
    </div>

    <div class="grid gap-6 lg:grid-cols-[16rem_1fr]">
        {{-- Filter kiri --}}
        <aside class="card h-fit space-y-6 p-5 lg:sticky lg:top-36" :class="filterOpen ? 'block' : 'hidden lg:block'">
            <div>
                <p class="mb-2 text-sm font-semibold">Kategori</p>
                <div class="space-y-2">
                    @foreach ($categories as $c)
                        <label class="flex cursor-pointer items-center gap-2.5 text-sm">
                            <input type="checkbox" value="{{ $c['id_kategori'] }}" :checked="kategori.includes({{ $c['id_kategori'] }})"
                                   @change="$event.target.checked ? kategori.push({{ $c['id_kategori'] }}) : kategori = kategori.filter(k => k !== {{ $c['id_kategori'] }})">
                            {{ $c['nama_kategori'] }}
                        </label>
                    @endforeach
                </div>
            </div>
            <div>
                <p class="mb-2 text-sm font-semibold">Rentang harga (Rp)</p>
                <div class="flex items-center gap-2">
                    <input type="number" min="0" step="10000" placeholder="Min" x-model="min" aria-label="Harga minimum">
                    <span class="text-ink-400">-</span>
                    <input type="number" min="0" step="10000" placeholder="Maks" x-model="max" aria-label="Harga maksimum">
                </div>
            </div>
            <div>
                <p class="mb-2 text-sm font-semibold">Label</p>
                <div class="space-y-2 text-sm">
                    <label class="flex cursor-pointer items-center gap-2.5"><input type="checkbox" x-model="flash"> Flash sale</label>
                    <label class="flex cursor-pointer items-center gap-2.5"><input type="checkbox" x-model="baru"> New arrival</label>
                </div>
            </div>
            <button class="btn-outline w-full" @click="reset()">Reset filter</button>
        </aside>

        {{-- Grid produk kanan --}}
        <div>
            <p x-show="q" x-cloak class="mb-3 text-sm text-ink-500">Hasil pencarian untuk "<strong x-text="q"></strong>"</p>
            <div class="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 xl:grid-cols-4">
                @foreach ($products as $p)
                    <div class="h-full" x-show="match({{ $p['id_produk'] }})" :style="{ order: rank({{ $p['id_produk'] }}) }">
                        <x-product-card :product="$p" />
                    </div>
                @endforeach
            </div>
            <div x-show="count === 0" x-cloak class="card mt-4 p-10 text-center">
                <p class="font-semibold">Produk tidak ditemukan</p>
                <p class="mt-1 text-sm text-ink-500">Coba ubah atau reset filter.</p>
                <button class="btn-primary mt-4" @click="reset()">Reset filter</button>
            </div>
        </div>
    </div>
</div>
@endsection
