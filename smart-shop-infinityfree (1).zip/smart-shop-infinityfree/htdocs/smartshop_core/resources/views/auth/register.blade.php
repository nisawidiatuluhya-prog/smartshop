@extends('layouts.app')
@section('title', 'Daftar')

@section('content')
<div class="mx-auto max-w-md px-4 py-10 sm:py-14">
    <form method="POST" action="{{ route('register.store') }}" class="card w-full space-y-4 p-6 shadow-xl shadow-accent-600/10 sm:p-8"
          x-data="authForm('register', @js(['nama' => old('nama'), 'email' => old('email'), 'telp' => old('telp')]))" @submit.prevent="submit()" novalidate>
        @csrf
        <div>
            <h1 class="text-2xl font-extrabold">Buat akun</h1>
            <p class="mt-1 text-sm text-ink-500">Daftar gratis untuk mulai belanja di Prima Smart Shop.</p>
        </div>
        <div>
            <label class="label" for="nama">Nama lengkap</label>
            <input id="nama" name="nama" x-model="f.nama" autocomplete="name" :class="err.nama && '!border-sale-500'">
            <p class="field-error" x-text="err.nama" x-show="err.nama"></p>
            @error('nama') <p class="field-error">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="email">Email</label>
            <input id="email" name="email" type="email" x-model="f.email" autocomplete="email" :class="err.email && '!border-sale-500'">
            <p class="field-error" x-text="err.email" x-show="err.email"></p>
            @error('email') <p class="field-error" x-show="!err.email">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="telp">Nomor telepon</label>
            <input id="telp" name="telp" type="tel" x-model="f.telp" placeholder="081234567890" autocomplete="tel" :class="err.telp && '!border-sale-500'">
            <p class="field-error" x-text="err.telp" x-show="err.telp"></p>
            @error('telp') <p class="field-error">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="password">Kata sandi</label>
            <input id="password" name="password" type="password" x-model="f.password" autocomplete="new-password" :class="err.password && '!border-sale-500'">
            <p class="field-error" x-text="err.password" x-show="err.password"></p>
            @error('password') <p class="field-error">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="password2">Ulangi kata sandi</label>
            <input id="password2" name="password_confirmation" type="password" x-model="f.password2" autocomplete="new-password" :class="err.password2 && '!border-sale-500'">
            <p class="field-error" x-text="err.password2" x-show="err.password2"></p>
        </div>
        <button class="btn-primary w-full" :disabled="loading">Daftar</button>
        <p class="text-center text-sm text-ink-500">Sudah punya akun? <a href="{{ route('login') }}" class="font-semibold text-accent-700 hover:underline">Masuk</a></p>
    </form>
</div>
@endsection
