@extends('layouts.app')
@section('title', 'Masuk')

@section('content')
<div class="mx-auto grid max-w-5xl items-center gap-8 px-4 py-10 sm:py-16 md:grid-cols-2">
    <div class="relative hidden overflow-hidden rounded-3xl bg-[linear-gradient(130deg,#1e1b4b,#4c1d95,#86198f,#be185d)] bg-[length:300%_300%] p-10 text-white animate-gradient md:block">
        <div class="absolute -right-10 -top-10 h-48 w-48 animate-blob rounded-full bg-fuchsia-400/40 blur-3xl"></div>
        <p class="relative text-3xl font-extrabold leading-tight">Selamat datang kembali.</p>
        <p class="relative mt-3 text-white/80">Masuk untuk checkout, melacak pesanan, dan ditemani Smart AI Assistant.</p>
        <ul class="relative mt-6 space-y-2 text-sm text-white/90">
            <li>✓ Bayar COD atau transfer bank</li><li>✓ Lacak pesanan langkah demi langkah</li><li>✓ Rekomendasi outfit dari AI</li>
        </ul>
    </div>

    <form method="POST" action="{{ route('login.attempt') }}" class="card w-full space-y-4 p-6 shadow-xl shadow-accent-600/10 sm:p-8"
          x-data="authForm('login', @js(['email' => old('email')]))" @submit.prevent="submit()" novalidate>
        @csrf
        <div>
            <h1 class="text-2xl font-extrabold">Masuk</h1>
            <p class="mt-1 text-sm text-ink-500">Masuk sebagai pelanggan Prima Smart Shop.</p>
        </div>
        @if (session('error')) <p class="rounded-lg bg-sale-100 px-3 py-2 text-sm text-sale-600">{{ session('error') }}</p> @endif
        <div>
            <label class="label" for="email">Email</label>
            <input id="email" name="email" type="email" x-model="f.email" autocomplete="email" :class="(err.email || @js($errors->has('email'))) && '!border-sale-500'">
            <p class="field-error" x-text="err.email" x-show="err.email"></p>
            @error('email') <p class="field-error" x-show="!err.email">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="password">Kata sandi</label>
            <div class="relative">
                <input id="password" name="password" :type="show ? 'text' : 'password'" x-model="f.password" autocomplete="current-password" :class="err.password && '!border-sale-500'">
                <button type="button" class="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-accent-600" @click="show = !show" x-text="show ? 'Sembunyikan' : 'Lihat'"></button>
            </div>
            <p class="field-error" x-text="err.password" x-show="err.password"></p>
            @error('password') <p class="field-error">{{ $message }}</p> @enderror
        </div>
        <button class="btn-primary w-full" :disabled="loading">Masuk</button>
        <p class="text-center text-sm text-ink-500">Belum punya akun? <a href="{{ route('register') }}" class="font-semibold text-accent-700 hover:underline">Daftar gratis</a></p>
        <div class="rounded-xl bg-accent-50 p-3 text-xs text-ink-600">
            <p class="font-semibold text-accent-700">Akun contoh pelanggan</p>
            <p>Email: <code>sari@example.com</code> &middot; Sandi: <code>sari12345</code></p>
        </div>
        <p class="text-center text-xs text-ink-400">Admin? <a href="{{ route('admin.login') }}" class="underline">Masuk lewat halaman admin</a></p>
    </form>
</div>
@endsection
