@extends('layouts.app')
@section('title', 'Pesanan ' . $kode)

@section('content')
{{-- Setelah pesanan berhasil dibuat, kosongkan keranjang di browser --}}
@if (session('order_baru'))
    <div x-data x-init="$store.cart.clear()"></div>
@endif

<div class="mx-auto max-w-3xl px-4 py-6 sm:px-6 sm:py-8" x-data="trackingPage(@js($order))">
    <div class="space-y-5">
        <div class="flex flex-wrap items-center justify-between gap-2">
            <div>
                <h1 class="text-2xl font-extrabold">Pesanan #<span x-text="order.kode"></span></h1>
                <p class="text-sm text-ink-500" x-text="'Dipesan ' + order.tanggal_order + ' · ' + order.metode_pembayaran"></p>
            </div>
            <span class="rounded-full px-3 py-1 text-sm font-semibold" :class="badge(status)" x-text="status"></span>
        </div>

        <section class="card p-5 sm:p-6">
            <x-status-timeline expr="status" />
            <div class="mt-6 rounded-xl bg-accent-50 p-4 text-sm">
                <p class="font-semibold text-accent-700">Catatan kurir</p>
                <p class="mt-1 text-ink-700" x-text="catatan"></p>
                <p class="mt-1 text-xs text-ink-500" x-text="'Pembaruan terakhir: ' + order.tracking.waktu_update"></p>
            </div>
            <p x-show="order.metode_pembayaran === 'Transfer' && status === 'Menunggu Verifikasi'" class="mt-3 text-sm text-amber-700">Bukti pembayaran sedang diperiksa admin. Biasanya selesai dalam 1x24 jam.</p>
        </section>

        <section class="card p-5">
            <h2 class="mb-3 font-semibold">Barang dipesan</h2>
            <ul class="divide-y divide-ink-100 text-sm">
                <template x-for="i in order.items" :key="i.nama_produk">
                    <li class="flex justify-between gap-3 py-2.5">
                        <span><span x-text="i.jumlah_beli"></span>x <span x-text="i.nama_produk"></span></span>
                        <span class="shrink-0 font-medium" x-text="rupiah(i.harga_satuan * i.jumlah_beli)"></span>
                    </li>
                </template>
            </ul>
            <div class="mt-3 space-y-1.5 border-t border-ink-100 pt-3 text-sm">
                <div class="flex justify-between"><span class="text-ink-500">Subtotal</span><span x-text="rupiah(subtotal)"></span></div>
                <div class="flex justify-between"><span class="text-ink-500" x-text="'Ongkir (' + order.kurir + ')'"></span><span x-text="rupiah(order.ongkir)"></span></div>
                <div class="flex justify-between text-base font-bold"><span>Total</span><span x-text="rupiah(order.total_harga)"></span></div>
            </div>
        </section>

        <section class="card p-5 text-sm">
            <h2 class="mb-2 font-semibold">Dikirim ke</h2>
            <p class="font-medium" x-text="order.pelanggan + ' · ' + order.telepon"></p>
            <p class="text-ink-500" x-text="order.alamat"></p>
        </section>

        <section class="card p-5">
            <h2 class="mb-3 font-semibold">Riwayat status</h2>
            <ol class="space-y-2 text-sm">
                <template x-for="(r, n) in order.riwayat" :key="n">
                    <li class="flex justify-between gap-3"><span class="font-medium" x-text="r.status"></span><span class="text-ink-500" x-text="r.waktu"></span></li>
                </template>
            </ol>
        </section>

        <a href="{{ route('pesanan.index') }}" class="inline-block text-sm font-semibold text-accent-600 hover:underline">&larr; Semua pesanan saya</a>
    </div>
</div>
@endsection
