<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Dashboard') | Admin PRIMA SMART SHOP</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body x-data="{ sidebar: false }" @keydown.escape.window="sidebar = false">
    <div class="flex min-h-screen">
        {{-- Overlay HP --}}
        <div x-show="sidebar" x-cloak x-transition.opacity @click="sidebar = false" class="fixed inset-0 z-30 bg-ink-900/40 lg:hidden"></div>

        <x-admin-sidebar />

        <div class="flex min-w-0 flex-1 flex-col">
            <header class="glass sticky top-0 z-20 flex h-14 items-center justify-between border-b border-white/60 px-4 sm:px-6">
                <div class="flex items-center gap-3">
                    <button class="rounded-lg p-2 hover:bg-ink-100 lg:hidden" @click="sidebar = true" aria-label="Buka menu">
                        <x-icon name="menu" class="h-5 w-5" />
                    </button>
                    <h1 class="text-base font-semibold sm:text-lg">@yield('heading', 'Dashboard')</h1>
                </div>
                <div class="flex items-center gap-3 text-sm">
                    <a href="{{ route('home') }}" class="hidden text-ink-500 hover:text-ink-900 sm:inline" target="_blank">Lihat toko</a>
                    <span class="hidden text-ink-600 sm:inline">{{ session('smartshop.user.nama') }}</span>
                    <span class="flex h-8 w-8 items-center justify-center rounded-full bg-brand-gradient text-xs font-semibold text-white">AD</span>
                </div>
            </header>

            <main class="flex-1 p-4 sm:p-6">
                <x-flash />
                @yield('content')
            </main>
        </div>
    </div>
    <x-toast />
</body>
</html>
