<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Belanja Fashion, Kosmetik, Sepatu & Tas') | PRIMA SMART SHOP</title>
    <meta name="description" content="Prima Smart Shop - pusat transaksi digital modern dengan layanan belanja pintar serba ada.">
    <script>document.documentElement.classList.add('js')</script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    {{-- Katalog contoh dikirim ke JavaScript (filter, keranjang, AI widget) --}}
    <script>window.SS = @json($ssData, JSON_HEX_TAG | JSON_HEX_AMP);</script>
</head>
<body class="flex min-h-screen flex-col">
    <x-navbar :categories="$navCategories" />
    <x-flash />

    <main class="flex-1">
        @yield('content')
    </main>

    <x-footer />
    <x-ai-chat-widget />
    <x-toast />
</body>
</html>
