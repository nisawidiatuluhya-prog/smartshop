@extends('layouts.admin')
@section('title', 'Pesanan ' . $order['kode'])
@section('heading', 'Detail pesanan #' . $order['kode'])

@section('content')
@php $menunggu = $order['status_pesanan'] === 'Menunggu Verifikasi'; @endphp
<div class="grid gap-6 lg:grid-cols-[1fr_22rem]">
    <div class="space-y-6">
        <section class="card p-5">
            <div class="flex flex-wrap items-center justify-between gap-2">
                <h2 class="font-semibold">Barang dipesan</h2>
                <span class="rounded-full px-3 py-1 text-xs font-semibold {{ status_badge($order['status_pesanan']) }}">{{ $order['status_pesanan'] }}</span>
            </div>
            <ul class="mt-3 divide-y divide-ink-100 text-sm">
                @foreach ($order['items'] as $i)
                    <li class="flex justify-between gap-3 py-2.5"><span>{{ $i['jumlah_beli'] }}x {{ $i['nama_produk'] }} <span class="text-ink-400">@ {{ rupiah($i['harga_satuan']) }}</span></span><span class="shrink-0 font-medium">{{ rupiah($i['harga_satuan'] * $i['jumlah_beli']) }}</span></li>
                @endforeach
            </ul>
            <div class="mt-3 space-y-1.5 border-t border-ink-100 pt-3 text-sm">
                <div class="flex justify-between"><span class="text-ink-500">Ongkir ({{ $order['kurir'] }})</span><span>{{ rupiah($order['ongkir']) }}</span></div>
                <div class="flex justify-between text-base font-bold"><span>Total</span><span>{{ rupiah($order['total_harga']) }}</span></div>
            </div>
        </section>

        <section class="card grid gap-4 p-5 text-sm sm:grid-cols-2">
            <div><p class="text-ink-500">Penerima</p><p class="font-medium">{{ $order['pelanggan'] }}</p><p>{{ $order['telepon'] }}</p></div>
            <div><p class="text-ink-500">Alamat pengiriman</p><p>{{ $order['alamat'] }}</p></div>
            <div><p class="text-ink-500">Tanggal order</p><p class="font-medium">{{ \Carbon\Carbon::parse($order['tanggal_order'])->format('d M Y') }}</p></div>
            <div><p class="text-ink-500">Metode pembayaran</p><p class="font-medium">{{ $order['metode_pembayaran'] }}</p></div>
        </section>

        @if ($order['metode_pembayaran'] === 'Transfer')
            <section class="card p-5">
                <h2 class="mb-3 font-semibold">Bukti pembayaran</h2>
                @if ($order['bukti_url'])
                    <img src="{{ $order['bukti_url'] }}" alt="Bukti pembayaran" class="max-h-96 rounded-xl border border-ink-200">
                @else
                    <div class="flex h-44 flex-col items-center justify-center rounded-xl border border-dashed border-ink-300 bg-ink-50 text-ink-400">
                        <x-icon name="photo" class="h-10 w-10" />
                        <p class="mt-1 text-sm">{{ $order['bukti_bayar'] }}</p>
                        <p class="text-xs">Placeholder (pesanan contoh tidak punya foto)</p>
                    </div>
                @endif
            </section>
        @endif

        <section class="card p-5">
            <h2 class="mb-3 font-semibold">Riwayat status</h2>
            <ol class="space-y-2 text-sm">
                @foreach ($order['riwayat'] as $r)
                    <li class="flex justify-between gap-3"><span class="font-medium">{{ $r['status'] }}</span><span class="text-ink-500">{{ $r['waktu'] }}</span></li>
                @endforeach
            </ol>
        </section>
    </div>

    <aside class="space-y-6">
        <section class="card space-y-4 p-5">
            <h2 class="font-semibold">Status pesanan</h2>
            <x-status-timeline :status="$order['status_pesanan']" />

            @if ($order['metode_pembayaran'] === 'Transfer')
                @if ($menunggu)
                    <form method="POST" action="{{ route('admin.pesanan.verifikasi', $order['kode']) }}">@csrf
                        <button class="btn-primary w-full">Verifikasi pembayaran</button>
                    </form>
                @else
                    <p class="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">Pembayaran sudah terverifikasi.</p>
                @endif
            @else
                <p class="rounded-lg bg-ink-100 px-3 py-2 text-sm text-ink-600">Pesanan COD tidak perlu verifikasi pembayaran.</p>
            @endif

            <form method="POST" action="{{ route('admin.pesanan.status', $order['kode']) }}">@csrf
                <label class="label" for="status">Update status pengiriman</label>
                <select id="status" name="status" onchange="this.form.submit()" {{ $menunggu ? 'disabled' : '' }}>
                    @foreach (['Diproses', 'Dikirim', 'Selesai'] as $s)
                        <option value="{{ $s }}" {{ $order['status_pesanan'] === $s ? 'selected' : '' }}>{{ $s }}</option>
                    @endforeach
                </select>
                @if ($menunggu) <p class="mt-1 text-xs text-ink-400">Verifikasi pembayaran terlebih dahulu.</p> @endif
            </form>
            <a href="{{ route('pesanan.show', $order['kode']) }}" target="_blank" class="block text-center text-sm font-medium text-accent-600 hover:underline">Lihat halaman pelacakan pelanggan</a>
        </section>
    </aside>
</div>
@endsection
