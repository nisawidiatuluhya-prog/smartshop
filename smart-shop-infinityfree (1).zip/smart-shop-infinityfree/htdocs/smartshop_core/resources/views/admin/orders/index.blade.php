@extends('layouts.admin')
@section('title', 'Pesanan')
@section('heading', 'Pesanan')

@section('content')
<div class="card p-5">
    <div class="-mx-5 overflow-x-auto px-5">
        <table class="w-full min-w-[46rem]">
            <thead class="border-b border-ink-200"><tr>
                <th class="th">No. pesanan</th><th class="th">Pelanggan</th><th class="th">Tanggal</th><th class="th">Metode</th><th class="th">Total</th><th class="th">Status</th><th class="th"></th>
            </tr></thead>
            <tbody class="divide-y divide-ink-100">
                @forelse ($orders as $o)
                    <tr>
                        <td class="td font-medium">#{{ $o['kode'] }}</td>
                        <td class="td">{{ $o['pelanggan'] }}</td>
                        <td class="td text-ink-500">{{ \Carbon\Carbon::parse($o['tanggal_order'])->format('d M Y') }}</td>
                        <td class="td">{{ $o['metode_pembayaran'] }}</td>
                        <td class="td">{{ rupiah($o['total_harga']) }}</td>
                        <td class="td"><span class="rounded-full px-2.5 py-0.5 text-xs font-semibold {{ status_badge($o['status_pesanan']) }}">{{ $o['status_pesanan'] }}</span></td>
                        <td class="td text-right"><a href="{{ route('admin.pesanan.show', $o['kode']) }}" class="btn-outline !px-3 !py-1.5">Detail</a></td>
                    </tr>
                @empty
                    <tr><td colspan="7" class="py-10 text-center text-sm text-ink-500">Belum ada pesanan.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
