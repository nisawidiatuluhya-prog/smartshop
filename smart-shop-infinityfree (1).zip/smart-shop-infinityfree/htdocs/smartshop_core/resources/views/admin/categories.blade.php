@extends('layouts.admin')
@section('title', 'Kelola kategori')
@section('heading', 'Kelola kategori')

@section('content')
<div class="grid gap-6 lg:grid-cols-[22rem_1fr]"
     x-data="{
        list: @js($categories),
        editId: null,
        name: @js(old('nama_kategori', '')),
        confirmId: null,
        get target() { return this.list.find(c => c.id_kategori === this.confirmId); },
        get formAction() { return this.editId ? '{{ url('/admin/kategori') }}/' + this.editId : '{{ route('admin.kategori.simpan') }}'; },
        slug(s) { return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''); },
        edit(c) { this.editId = c.id_kategori; this.name = c.nama_kategori; this.$nextTick(() => this.$refs.input.focus()); },
        cancel() { this.editId = null; this.name = ''; }
     }">
    <form method="POST" :action="formAction" class="card h-fit space-y-3 p-5">
        @csrf
        <input type="hidden" name="_method" value="PUT" :disabled="!editId">
        <h2 class="font-semibold" x-text="editId ? 'Ubah kategori' : 'Tambah kategori'"></h2>
        <div>
            <label class="label" for="nk">Nama kategori</label>
            <input id="nk" name="nama_kategori" x-ref="input" x-model="name" placeholder="Contoh: Aksesoris" class="@error('nama_kategori') !border-sale-500 @enderror">
            @error('nama_kategori') <p class="field-error">{{ $message }}</p> @enderror
            <p class="mt-1 text-xs text-ink-400" x-show="name">Slug: <span x-text="slug(name)"></span></p>
        </div>
        <div class="flex gap-2">
            <button type="submit" class="btn-primary flex-1" x-text="editId ? 'Simpan perubahan' : 'Tambah'"></button>
            <button type="button" class="btn-outline" x-show="editId" x-cloak @click="cancel()">Batal</button>
        </div>
    </form>

    <div class="card p-5">
        <div class="-mx-5 overflow-x-auto px-5">
            <table class="w-full min-w-[28rem]">
                <thead class="border-b border-ink-200"><tr><th class="th">Kategori</th><th class="th">Slug</th><th class="th">Produk</th><th class="th text-right">Aksi</th></tr></thead>
                <tbody class="divide-y divide-ink-100">
                    <template x-for="c in list" :key="c.id_kategori">
                        <tr>
                            <td class="td font-medium" x-text="c.nama_kategori"></td>
                            <td class="td text-ink-500" x-text="c.slug"></td>
                            <td class="td" x-text="c.jumlah_produk"></td>
                            <td class="td"><div class="flex justify-end gap-1">
                                <button type="button" class="rounded-lg p-2 hover:bg-ink-100" @click="edit(c)" aria-label="Ubah"><x-icon name="pencil" class="h-4 w-4" /></button>
                                <button type="button" class="rounded-lg p-2 text-sale-600 hover:bg-sale-100" @click="confirmId = c.id_kategori" aria-label="Hapus"><x-icon name="trash" class="h-4 w-4" /></button>
                            </div></td>
                        </tr>
                    </template>
                </tbody>
            </table>
        </div>
    </div>

    <div x-show="confirmId" x-cloak x-transition.opacity class="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/50 p-4" @click.self="confirmId = null" @keydown.escape.window="confirmId = null">
        <div class="card w-full max-w-sm p-6" role="dialog" aria-modal="true">
            <h3 class="text-lg font-semibold">Hapus kategori?</h3>
            <p class="mt-2 text-sm text-ink-500">Kategori <strong x-text="target?.nama_kategori"></strong> akan dihapus. Kategori yang masih berisi produk akan ditolak.</p>
            <form method="POST" :action="'{{ url('/admin/kategori') }}/' + confirmId" class="mt-5 flex justify-end gap-2">
                @csrf
                @method('DELETE')
                <button type="button" class="btn-outline" @click="confirmId = null">Batal</button>
                <button type="submit" class="btn bg-sale-600 text-white hover:bg-sale-500">Ya, hapus</button>
            </form>
        </div>
    </div>
</div>
@endsection
