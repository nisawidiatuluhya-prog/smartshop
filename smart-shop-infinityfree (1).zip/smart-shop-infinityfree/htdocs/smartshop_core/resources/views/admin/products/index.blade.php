@extends('layouts.admin')
@section('title', 'Manajemen produk')
@section('heading', 'Manajemen produk')

@section('content')
<div class="card p-5"
     x-data="{
        q: '',
        all: @js($products),
        confirmId: null,
        get list() { const k = this.q.trim().toLowerCase(); return k ? this.all.filter(p => p.nama_produk.toLowerCase().includes(k) || (p.kategori || '').toLowerCase().includes(k)) : this.all; },
        get target() { return this.all.find(p => p.id_produk === this.confirmId); },
        rupiah(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }
     }">
    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <input x-model="q" type="search" placeholder="Cari produk..." class="sm:max-w-xs" aria-label="Cari produk">
        <a href="{{ route('admin.produk.tambah') }}" class="btn-primary"><x-icon name="plus" class="h-4 w-4" /> Tambah produk</a>
    </div>

    <div class="-mx-5 mt-4 overflow-x-auto px-5">
        <table class="w-full min-w-[44rem]">
            <thead class="border-b border-ink-200"><tr>
                <th class="th">Produk</th><th class="th">Kategori</th><th class="th">Harga</th><th class="th">Stok</th><th class="th">Label</th><th class="th text-right">Aksi</th>
            </tr></thead>
            <tbody class="divide-y divide-ink-100">
                <template x-for="p in list" :key="p.id_produk">
                    <tr>
                        <td class="td"><div class="flex items-center gap-3">
                            <span class="block h-11 w-11 shrink-0 overflow-hidden rounded-lg" x-html="p.thumb"></span>
                            <span class="font-medium" x-text="p.nama_produk"></span>
                        </div></td>
                        <td class="td" x-text="p.kategori"></td>
                        <td class="td" x-text="rupiah(p.harga)"></td>
                        <td class="td" :class="p.stok < 25 && 'font-semibold text-sale-600'" x-text="p.stok"></td>
                        <td class="td"><span x-show="p.flag_status" class="rounded-full bg-ink-100 px-2.5 py-0.5 text-xs font-medium" x-text="p.flag_status"></span><span x-show="!p.flag_status" class="text-ink-300">-</span></td>
                        <td class="td"><div class="flex justify-end gap-1">
                            <a :href="'{{ url('/admin/produk') }}/' + p.id_produk + '/edit'" class="rounded-lg p-2 hover:bg-ink-100" aria-label="Ubah"><x-icon name="pencil" class="h-4 w-4" /></a>
                            <button type="button" class="rounded-lg p-2 text-sale-600 hover:bg-sale-100" @click="confirmId = p.id_produk" aria-label="Hapus"><x-icon name="trash" class="h-4 w-4" /></button>
                        </div></td>
                    </tr>
                </template>
            </tbody>
        </table>
        <p x-show="list.length === 0" x-cloak class="py-8 text-center text-sm text-ink-500">Tidak ada produk.</p>
    </div>

    {{-- Konfirmasi hapus --}}
    <div x-show="confirmId" x-cloak x-transition.opacity class="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/50 p-4" @click.self="confirmId = null" @keydown.escape.window="confirmId = null">
        <div class="card w-full max-w-sm p-6" role="dialog" aria-modal="true">
            <h3 class="text-lg font-semibold">Hapus produk?</h3>
            <p class="mt-2 text-sm text-ink-500">Produk <strong x-text="target?.nama_produk"></strong> akan dihapus permanen dari database. Produk yang sudah ada di pesanan tidak bisa dihapus.</p>
            <form method="POST" :action="'{{ url('/admin/produk') }}/' + confirmId" class="mt-5 flex justify-end gap-2">
                @csrf
                @method('DELETE')
                <button type="button" class="btn-outline" @click="confirmId = null">Batal</button>
                <button type="submit" class="btn bg-sale-600 text-white hover:bg-sale-500">Ya, hapus</button>
            </form>
        </div>
    </div>
</div>
@endsection
