@extends('layouts.admin')
@section('title', $product ? 'Ubah produk' : 'Tambah produk')
@section('heading', $product ? 'Ubah produk' : 'Tambah produk')

@section('content')
@php $v = fn ($key, $default = '') => old($key, $product[$key] ?? $default); @endphp

<form method="POST"
      action="{{ $product ? route('admin.produk.ubah', $product['id_produk']) : route('admin.produk.simpan') }}"
      enctype="multipart/form-data"
      class="card mx-auto max-w-3xl space-y-5 p-5 sm:p-6"
      x-data="{ preview: null, pick(e) { const f = e.target.files[0]; this.preview = f ? URL.createObjectURL(f) : null } }">
    @csrf
    @if ($product) @method('PUT') @endif

    @if (session('error'))
        <div class="rounded-xl border border-sale-500 p-3 text-sm text-sale-500">{{ session('error') }}</div>
    @endif

    <div>
        <label class="label" for="nama_produk">Nama produk</label>
        <input id="nama_produk" name="nama_produk" value="{{ $v('nama_produk') }}" class="@error('nama_produk') !border-sale-500 @enderror">
        @error('nama_produk') <p class="field-error">{{ $message }}</p> @enderror
    </div>

    <div class="grid gap-5 sm:grid-cols-2">
        <div>
            <label class="label" for="id_kategori">Kategori</label>
            <select id="id_kategori" name="id_kategori" class="@error('id_kategori') !border-sale-500 @enderror">
                <option value="">Pilih kategori</option>
                @foreach ($categories as $c)
                    <option value="{{ $c['id_kategori'] }}" @selected((string) $v('id_kategori') === (string) $c['id_kategori'])>{{ $c['nama_kategori'] }}</option>
                @endforeach
            </select>
            @error('id_kategori') <p class="field-error">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="flag_status">Label</label>
            <select id="flag_status" name="flag_status">
                <option value="">Tanpa label</option>
                @foreach (['Flash Sale', 'New Arrival'] as $l)
                    <option value="{{ $l }}" @selected($v('flag_status') === $l)>{{ $l }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="label" for="harga">Harga (Rp)</label>
            <input id="harga" name="harga" type="number" min="0" step="1000" value="{{ $v('harga') }}" class="@error('harga') !border-sale-500 @enderror">
            @error('harga') <p class="field-error">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="diskon">Diskon (%)</label>
            <input id="diskon" name="diskon" type="number" min="0" max="100" value="{{ $v('diskon', 0) }}" class="@error('diskon') !border-sale-500 @enderror">
            @error('diskon') <p class="field-error">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="stok">Stok</label>
            <input id="stok" name="stok" type="number" min="0" value="{{ $v('stok') }}" class="@error('stok') !border-sale-500 @enderror">
            @error('stok') <p class="field-error">{{ $message }}</p> @enderror
        </div>
    </div>

    <div>
        <label class="label" for="deskripsi">Deskripsi</label>
        <textarea id="deskripsi" name="deskripsi" rows="4" class="@error('deskripsi') !border-sale-500 @enderror">{{ $v('deskripsi') }}</textarea>
        @error('deskripsi') <p class="field-error">{{ $message }}</p> @enderror
    </div>

    <div>
        <label class="label" for="foto">Foto produk (JPG, PNG, WEBP, maks 2 MB)</label>
        <input id="foto" name="foto" type="file" accept="image/jpeg,image/png,image/webp" @change="pick($event)">
        @error('foto') <p class="field-error">{{ $message }}</p> @enderror
        <template x-if="preview"><img :src="preview" alt="Pratinjau" class="mt-3 h-40 w-40 rounded-xl border border-ink-200 object-cover"></template>
        @if ($product && $product['gambar'])
            <img x-show="!preview" src="{{ asset($product['gambar']) }}" alt="Foto saat ini" class="mt-3 h-40 w-40 rounded-xl border border-ink-200 object-cover">
            <p class="mt-1 text-xs" x-show="!preview">Foto saat ini. Pilih file baru untuk menggantinya.</p>
        @endif
    </div>

    <div class="flex justify-end gap-2 border-t border-ink-100 pt-5">
        <a href="{{ route('admin.produk') }}" class="btn-outline">Batal</a>
        <button type="submit" class="btn-primary">Simpan produk</button>
    </div>
</form>
@endsection
