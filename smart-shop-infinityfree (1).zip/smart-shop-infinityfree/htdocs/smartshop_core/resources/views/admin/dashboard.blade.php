@extends('layouts.admin')
@section('title', 'Dashboard')
@section('heading', 'Dashboard')

@section('content')
<div class="space-y-6">
    {{-- Ringkasan hari ini (dihitung dari tabel orders) --}}
    <div class="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <x-stat-card label="Penjualan hari ini" :value="rupiah($stats['penjualan_hari_ini'])" icon="chart" tone="violet" />
        <x-stat-card label="Pesanan baru" :value="$stats['pesanan_baru']" icon="orders" tone="sky" />
        <x-stat-card label="Barang laku" :value="$stats['barang_laku']" icon="bag" tone="emerald" />
        <x-stat-card label="Sepatu terjual" :value="$stats['sepatu_terjual']" icon="sparkles" tone="amber" />
    </div>

    {{-- Tanya AI analytics (jawaban pura-pura) --}}
    <section id="ai" class="card scroll-mt-20 p-5" x-data="adminAi">
        <h2 class="font-semibold">Tanya AI analytics</h2>
        <form class="mt-3 flex flex-col gap-2 sm:flex-row" @submit.prevent="ask()">
            <input x-model="q" placeholder="Berapa total sepatu yang terjual hari ini?" aria-label="Pertanyaan analytics">
            <button class="btn-primary shrink-0 sm:px-8">Tanya</button>
        </form>
        <div class="mt-3 flex flex-wrap gap-2">
            <template x-for="s in samples" :key="s">
                <button type="button" class="rounded-full border border-ink-200 px-3 py-1 text-xs text-ink-600 hover:border-ink-900" @click="ask(s)" x-text="s"></button>
            </template>
        </div>
        <div x-show="loading" x-cloak class="mt-3 rounded-xl bg-accent-50 p-4 text-sm text-accent-700">Menganalisis data...</div>
        <div x-show="answer" x-cloak x-transition class="mt-3 rounded-xl bg-accent-100 p-4 text-sm text-accent-700">
            <span class="font-semibold">Jawaban AI:</span> <span x-text="answer"></span>
        </div>
    </section>

    {{-- Pesanan menunggu verifikasi (dari database) --}}
    <section class="card p-5" x-data="{ proof: null }">
        <h2 class="font-semibold">Pesanan menunggu verifikasi</h2>
        <div class="-mx-5 mt-3 overflow-x-auto px-5">
            <table class="w-full min-w-[34rem]">
                <thead class="border-b border-ink-200"><tr>
                    <th class="th">No. pesanan</th><th class="th">Pelanggan</th><th class="th">Total</th><th class="th">Bukti bayar</th><th class="th">Aksi</th>
                </tr></thead>
                <tbody class="divide-y divide-ink-100">
                    @forelse ($pending as $o)
                        <tr>
                            <td class="td"><a href="{{ route('admin.pesanan.show', $o['kode']) }}" class="font-medium hover:underline">#{{ $o['kode'] }}</a></td>
                            <td class="td">{{ $o['pelanggan'] }}</td>
                            <td class="td">{{ rupiah($o['total_harga']) }}</td>
                            <td class="td"><button type="button" class="inline-flex items-center gap-1.5 text-accent-600 hover:underline" @click="proof = @js(['kode' => $o['kode'], 'file' => $o['bukti_bayar'], 'url' => $o['bukti_url']])"><x-icon name="eye" class="h-4 w-4" /> Lihat</button></td>
                            <td class="td">
                                <form method="POST" action="{{ route('admin.pesanan.verifikasi', $o['kode']) }}">@csrf
                                    <button class="btn-outline !px-3 !py-1.5">Verifikasi</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="py-8 text-center text-sm text-ink-500">Tidak ada pesanan yang menunggu verifikasi.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        {{-- Modal bukti bayar --}}
        <div x-show="proof" x-cloak x-transition.opacity class="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/50 p-4" @click.self="proof = null" @keydown.escape.window="proof = null">
            <div class="card max-h-[90vh] w-full max-w-sm overflow-y-auto p-5" x-show="proof">
                <div class="flex items-center justify-between"><h3 class="font-semibold" x-text="'Bukti bayar #' + (proof?.kode ?? '')"></h3><button type="button" @click="proof = null" aria-label="Tutup"><x-icon name="x" class="h-5 w-5" /></button></div>
                <template x-if="proof && proof.url"><img :src="proof.url" alt="Bukti pembayaran" class="mt-3 w-full rounded-xl border border-ink-200"></template>
                <template x-if="proof && !proof.url">
                    <div class="mt-3 flex aspect-[3/4] flex-col items-center justify-center rounded-xl border border-dashed border-ink-300 bg-ink-50 text-ink-400">
                        <x-icon name="photo" class="h-12 w-12" />
                        <p class="mt-2 text-sm" x-text="proof.file"></p>
                        <p class="text-xs">Placeholder (pesanan contoh tidak punya foto)</p>
                    </div>
                </template>
                <form method="POST" :action="'/admin/pesanan/' + (proof?.kode ?? '') + '/verifikasi'" class="mt-4">@csrf
                    <button class="btn-primary w-full">Verifikasi pembayaran</button>
                </form>
            </div>
        </div>
    </section>
</div>
@endsection
