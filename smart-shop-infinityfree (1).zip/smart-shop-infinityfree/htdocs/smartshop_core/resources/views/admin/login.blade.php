<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk Admin | PRIMA SMART SHOP</title>
    <script>document.documentElement.classList.add('js')</script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="relative flex min-h-screen items-center justify-center overflow-hidden bg-[linear-gradient(130deg,#1e1b4b,#4c1d95,#86198f,#be185d)] bg-[length:300%_300%] p-4 animate-gradient">
    <div class="absolute -left-20 -top-20 h-80 w-80 animate-blob rounded-full bg-fuchsia-500/40 blur-3xl"></div>
    <div class="absolute -bottom-24 -right-16 h-96 w-96 animate-blob rounded-full bg-violet-500/40 blur-3xl"></div>

    <form method="POST" action="{{ route('admin.login.attempt') }}" class="glass relative w-full max-w-sm space-y-4 rounded-3xl p-6 shadow-2xl sm:p-8"
          x-data="authForm('login', @js(['email' => old('email')]))" @submit.prevent="submit()" novalidate>
        @csrf
        <div class="text-center">
            <p class="text-2xl font-extrabold tracking-wide"><span class="text-brand-gradient">PRIMA</span> SMART SHOP</p>
            <p class="mt-1 text-sm text-ink-500">Masuk ke panel admin</p>
        </div>
        @if (session('error')) <p class="rounded-lg bg-sale-100 px-3 py-2 text-sm text-sale-600">{{ session('error') }}</p> @endif
        <div>
            <label class="label" for="email">Email admin</label>
            <input id="email" name="email" type="email" x-model="f.email" placeholder="admin@smartshop.test" :class="err.email && '!border-sale-500'">
            <p class="field-error" x-text="err.email" x-show="err.email"></p>
            @error('email') <p class="field-error" x-show="!err.email">{{ $message }}</p> @enderror
        </div>
        <div>
            <label class="label" for="password">Kata sandi</label>
            <input id="password" name="password" type="password" x-model="f.password" :class="err.password && '!border-sale-500'">
            <p class="field-error" x-text="err.password" x-show="err.password"></p>
            @error('password') <p class="field-error">{{ $message }}</p> @enderror
        </div>
        <button class="btn-primary w-full" :disabled="loading">Masuk</button>
        <a href="{{ route('home') }}" class="block text-center text-sm text-ink-500 hover:text-ink-900">Kembali ke toko</a>
    </form>
</body>
</html>
