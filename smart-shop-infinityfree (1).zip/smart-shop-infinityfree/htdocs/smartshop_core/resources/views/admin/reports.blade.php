@extends('layouts.admin')
@section('title', 'Laporan penjualan')
@section('heading', 'Laporan penjualan')

@section('content')
<div class="space-y-6">
    <div class="grid grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-4">
        <x-stat-card label="Total pendapatan 7 hari" :value="rupiah($total)" />
        <x-stat-card label="Total pesanan" :value="collect($laporan)->sum('pesanan')" />
        <x-stat-card label="Total barang terjual" :value="collect($laporan)->sum('barang')" />
    </div>

    <section class="card p-5">
        <h2 class="font-semibold">Pendapatan harian</h2>
        <div class="mt-4 flex h-56 items-end gap-2 border-b border-ink-200 sm:gap-4" role="img" aria-label="Grafik batang pendapatan 7 hari terakhir">
            @foreach ($laporan as $r)
                @php($tinggi = max(6, round($r['pendapatan'] / $max * 100)))
                <div class="group flex h-full flex-1 flex-col items-center justify-end">
                    <span class="mb-1 hidden text-[11px] font-semibold text-ink-600 sm:block">{{ number_format($r['pendapatan'] / 1000000, 1, ',', '.') }} jt</span>
                    <div class="w-full max-w-14 rounded-t-lg bg-gradient-to-t from-violet-600 via-fuchsia-500 to-rose-400 transition group-hover:brightness-110" style="height: {{ $tinggi }}%" title="{{ rupiah($r['pendapatan']) }}"></div>
                </div>
            @endforeach
        </div>
        <div class="mt-2 flex gap-2 sm:gap-4">
            @foreach ($laporan as $r)
                <span class="flex-1 text-center text-[11px] text-ink-500 sm:text-xs">{{ \Carbon\Carbon::parse($r['tanggal'])->format('d M') }}</span>
            @endforeach
        </div>
    </section>

    <section class="card p-5">
        <h2 class="font-semibold">Rincian per hari</h2>
        <div class="-mx-5 mt-3 overflow-x-auto px-5">
            <table class="w-full min-w-[28rem]">
                <thead class="border-b border-ink-200"><tr><th class="th">Tanggal</th><th class="th">Pesanan</th><th class="th">Barang terjual</th><th class="th text-right">Pendapatan</th></tr></thead>
                <tbody class="divide-y divide-ink-100">
                    @foreach (array_reverse($laporan) as $r)
                        <tr>
                            <td class="td">{{ \Carbon\Carbon::parse($r['tanggal'])->translatedFormat('d F Y') }}</td>
                            <td class="td">{{ $r['pesanan'] }}</td>
                            <td class="td">{{ $r['barang'] }}</td>
                            <td class="td text-right font-medium">{{ rupiah($r['pendapatan']) }}</td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot class="border-t border-ink-200"><tr><td class="td font-semibold" colspan="3">Total</td><td class="td text-right font-bold">{{ rupiah($total) }}</td></tr></tfoot>
            </table>
        </div>
    </section>
</div>
@endsection
