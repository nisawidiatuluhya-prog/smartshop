@extends('layouts.app')
@section('title', 'Beranda')

@section('content')
@php $login = session('smartshop.user'); @endphp

{{-- ================= HERO ================= --}}
<section class="relative overflow-hidden bg-[linear-gradient(130deg,#1e1b4b,#4c1d95,#86198f,#be185d)] bg-[length:300%_300%] text-white animate-gradient">
    <div class="absolute -left-24 -top-24 h-96 w-96 animate-blob rounded-full bg-fuchsia-500/40 blur-3xl"></div>
    <div class="absolute -bottom-32 right-0 h-[28rem] w-[28rem] animate-blob rounded-full bg-violet-500/40 blur-3xl [animation-delay:-6s]"></div>
    <span class="absolute left-[12%] top-[22%] animate-twinkle text-2xl text-white/70">✦</span>
    <span class="absolute right-[18%] top-[14%] animate-twinkle text-xl text-white/60 [animation-delay:-1s]">✦</span>
    <span class="absolute bottom-[18%] left-[46%] animate-twinkle text-lg text-white/60 [animation-delay:-2s]">✦</span>

    <div class="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 sm:py-20 lg:grid-cols-2">
        <div>
            <span class="glass-dark inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-3.5 py-1.5 text-xs font-medium backdrop-blur">
                <x-icon name="sparkles" class="h-3.5 w-3.5 animate-twinkle" /> Belanja dibantu Smart AI Assistant
            </span>
            <h1 class="mt-5 text-4xl font-extrabold leading-[1.1] sm:text-6xl">
                Tampil <span class="bg-gradient-to-r from-amber-200 via-pink-200 to-fuchsia-200 bg-clip-text text-transparent">memukau</span>,<br>belanja jadi mudah.
            </h1>
            <p class="mt-4 max-w-md text-base text-white/80 sm:text-lg">Pusat transaksi digital modern dengan layanan belanja pintar serba ada. Diskon sampai 30% di Flash Sale hari ini.</p>
            <div class="mt-7 flex flex-wrap gap-3">
                <a href="{{ route('shop') }}" class="btn bg-white !px-7 !py-3 text-base text-ink-900 shadow-xl shadow-black/20 hover:-translate-y-0.5 hover:bg-amber-50">Belanja sekarang <x-icon name="arrow" class="h-4 w-4" /></a>
                @unless ($login)
                    <a href="{{ route('register') }}" class="btn border border-white/40 !px-7 !py-3 text-base text-white backdrop-blur hover:bg-white/15">Daftar gratis</a>
                @endunless
            </div>
            <dl class="mt-9 grid max-w-md grid-cols-3 gap-4 text-center">
                @foreach ([['16+', 'Produk pilihan'], ['4', 'Kategori'], ['2', 'Cara bayar']] as [$n, $t])
                    <div class="rounded-2xl border border-white/15 bg-white/10 px-3 py-3 backdrop-blur"><dt class="text-xl font-extrabold sm:text-2xl">{{ $n }}</dt><dd class="text-[11px] text-white/70 sm:text-xs">{{ $t }}</dd></div>
                @endforeach
            </dl>
        </div>

        {{-- kartu produk melayang --}}
        <div class="relative mx-auto hidden h-[26rem] w-full max-w-md lg:block">
            @foreach (array_slice($flashSale, 0, 3) as $i => $p)
                @php $pos = [['left-0 top-8 w-56', '-6deg', '0s'], ['right-0 top-0 w-60', '5deg', '-2s'], ['left-16 bottom-0 w-52', '-2deg', '-4s']][$i]; @endphp
                <a href="{{ route('produk.show', $p['slug']) }}" class="absolute {{ $pos[0] }} animate-float rounded-3xl border border-white/40 bg-white/20 p-2 shadow-2xl backdrop-blur-md transition hover:z-10 hover:scale-105"
                   style="--r: {{ $pos[1] }}; animation-delay: {{ $pos[2] }}">
                    <x-product-image :product="$p" class="shine rounded-2xl" />
                    <div class="flex items-center justify-between px-2 pb-1 pt-2 text-ink-900">
                        <span class="truncate text-xs font-semibold">{{ $p['nama_produk'] }}</span>
                        <span class="ml-2 shrink-0 rounded-md bg-sale-600 px-1.5 py-0.5 text-[10px] font-bold text-white">-{{ $p['diskon'] }}%</span>
                    </div>
                </a>
            @endforeach
        </div>
    </div>

    {{-- pita berjalan --}}
    <div class="relative overflow-hidden border-y border-white/15 bg-black/20 py-2.5 backdrop-blur" aria-hidden="true">
        <div class="flex w-max animate-marquee gap-10 whitespace-nowrap text-sm font-medium text-white/85">
            @for ($r = 0; $r < 2; $r++)
                @foreach (['✦ Diskon hingga 30%', '✦ COD bayar di tempat', '✦ Transfer bank mudah', '✦ Lacak pesanan real-time', '✦ Tanya Smart AI Assistant', '✦ Produk baru setiap minggu'] as $t)
                    <span>{{ $t }}</span>
                @endforeach
            @endfor
        </div>
    </div>
</section>

<div class="mx-auto max-w-7xl space-y-16 px-4 pt-12 sm:px-6 sm:pt-16">

    {{-- ================= KATEGORI ================= --}}
    <section aria-labelledby="h-kategori" data-reveal>
        <div class="mb-6 text-center">
            <p class="text-sm font-semibold text-accent-600">Jelajahi</p>
            <h2 id="h-kategori" class="text-2xl font-extrabold sm:text-3xl">Belanja per kategori</h2>
        </div>
        <div class="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
            @foreach ($categories as $i => $c)
                <div data-reveal style="--d: {{ $i * 90 }}ms"><x-category-tile :category="$c" :product="$wakil[$c['id_kategori']] ?? null" /></div>
            @endforeach
        </div>
    </section>

    {{-- ================= FLASH SALE ================= --}}
    <section aria-labelledby="h-flash" data-reveal>
        <div class="mb-6 flex flex-wrap items-end justify-between gap-3">
            <div class="flex flex-wrap items-center gap-3">
                <h2 id="h-flash" class="text-2xl font-extrabold sm:text-3xl">Flash sale ⚡</h2>
                <div x-data="countdown" class="flex items-center gap-1 text-sm font-bold text-white" aria-label="Sisa waktu flash sale">
                    <span class="rounded-lg bg-ink-900 px-2 py-1" x-text="h"></span>:
                    <span class="rounded-lg bg-ink-900 px-2 py-1" x-text="m"></span>:
                    <span class="rounded-lg bg-sale-600 px-2 py-1" x-text="s"></span>
                </div>
            </div>
            <a href="{{ route('shop', ['flash' => 1]) }}" class="text-sm font-semibold text-accent-600 hover:underline">Lihat semua &rarr;</a>
        </div>
        <div class="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
            @foreach ($flashSale as $i => $p)
                <div data-reveal style="--d: {{ $i * 90 }}ms" class="h-full"><x-product-card :product="$p" /></div>
            @endforeach
        </div>
    </section>

    {{-- ================= CARA BELANJA ================= --}}
    <section data-reveal class="rounded-3xl border border-ink-200/80 bg-white p-6 sm:p-10">
        <h2 class="text-center text-2xl font-extrabold sm:text-3xl">Belanja gampang, <span class="text-brand-gradient">3 langkah</span></h2>
        <div class="mt-8 grid gap-6 sm:grid-cols-3">
            @foreach ([['Pilih produk', 'Jelajahi kategori atau tanya Smart AI Assistant untuk rekomendasi.', 'search'], ['Checkout', 'Isi alamat, pilih kurir, lalu bayar COD atau transfer bank.', 'bag'], ['Lacak pesanan', 'Pantau status dari verifikasi, diproses, dikirim, sampai selesai.', 'orders']] as $i => [$t, $d, $ic])
                <div class="relative text-center" data-reveal style="--d: {{ $i * 120 }}ms">
                    <span class="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-gradient text-white shadow-lg shadow-fuchsia-500/30"><x-icon :name="$ic" class="h-6 w-6" /></span>
                    <p class="mt-4 font-bold">{{ $i + 1 }}. {{ $t }}</p>
                    <p class="mt-1 text-sm text-ink-500">{{ $d }}</p>
                </div>
            @endforeach
        </div>
    </section>

    {{-- ================= UNGGULAN ================= --}}
    <section aria-labelledby="h-unggulan" data-reveal>
        <div class="mb-6 flex items-end justify-between">
            <div>
                <p class="text-sm font-semibold text-accent-600">Paling laris</p>
                <h2 id="h-unggulan" class="text-2xl font-extrabold sm:text-3xl">Produk unggulan</h2>
            </div>
            <a href="{{ route('shop') }}" class="text-sm font-semibold text-accent-600 hover:underline">Lihat semua &rarr;</a>
        </div>
        <div class="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
            @foreach ($unggulan as $i => $p)
                <div data-reveal style="--d: {{ $i * 90 }}ms" class="h-full"><x-product-card :product="$p" /></div>
            @endforeach
        </div>
    </section>

    {{-- ================= AI TEASER ================= --}}
    <section data-reveal class="relative overflow-hidden rounded-3xl bg-[linear-gradient(130deg,#312e81,#6d28d9,#c026d3)] bg-[length:250%_250%] p-8 text-white animate-gradient sm:p-12">
        <div class="absolute -right-10 -top-10 h-56 w-56 animate-blob rounded-full bg-pink-400/40 blur-3xl"></div>
        <div class="relative grid items-center gap-6 md:grid-cols-2">
            <div>
                <p class="flex items-center gap-2 text-sm font-semibold text-pink-200"><x-icon name="sparkles" class="h-4 w-4 animate-twinkle" /> Smart AI Assistant</p>
                <h2 class="mt-2 text-2xl font-extrabold sm:text-3xl">Bingung pilih outfit? Tanya AI-nya.</h2>
                <p class="mt-2 text-white/80">Ketik "outfit santai", "sepatu", "tas", atau "kosmetik", dan dapatkan rekomendasi produk seketika. Klik tombol <strong>Tanya Smart AI Assistant</strong> di pojok kanan bawah.</p>
            </div>
            <div class="space-y-2.5 text-sm">
                <p class="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-sm bg-white/20 px-4 py-2 backdrop-blur">Rekomendasi outfit santai dong</p>
                <p class="w-fit max-w-[90%] rounded-2xl rounded-bl-sm bg-white px-4 py-2 text-ink-900">Coba kaos oversize + celana kulot + sneakers putih ✨</p>
            </div>
        </div>
    </section>

    {{-- ================= BARU ================= --}}
    <section data-reveal aria-labelledby="h-baru">
        <div class="mb-6 flex items-end justify-between">
            <div>
                <p class="text-sm font-semibold text-accent-600">Baru masuk</p>
                <h2 id="h-baru" class="text-2xl font-extrabold sm:text-3xl">New arrival</h2>
            </div>
            <a href="{{ route('shop') }}" class="text-sm font-semibold text-accent-600 hover:underline">Lihat semua &rarr;</a>
        </div>
        <div class="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
            @foreach ($baru as $i => $p)
                <div data-reveal style="--d: {{ $i * 90 }}ms" class="h-full"><x-product-card :product="$p" /></div>
            @endforeach
        </div>
    </section>

    {{-- ================= TESTIMONI ================= --}}
    <section data-reveal>
        <h2 class="mb-6 text-center text-2xl font-extrabold sm:text-3xl">Kata pelanggan</h2>
        <div class="grid gap-4 md:grid-cols-3">
            @foreach ([['Sari D.', 'Medan', 'Sneakers-nya nyaman banget, pengiriman cepat. Rekomendasi dari AI-nya juga pas!'], ['Budi S.', 'Binjai', 'COD jadi tenang belanjanya. Lacak pesanannya jelas, tahu sudah sampai mana.'], ['Rina M.', 'Deli Serdang', 'Serum dan sunscreen-nya bagus, harganya bersahabat. Pasti repeat order.']] as $i => [$n, $k, $t])
                <figure class="card p-6 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-accent-600/10" data-reveal style="--d: {{ $i * 100 }}ms">
                    <p class="text-amber-400">★★★★★</p>
                    <blockquote class="mt-2 text-sm text-ink-600">“{{ $t }}”</blockquote>
                    <figcaption class="mt-4 flex items-center gap-3">
                        <span class="flex h-9 w-9 items-center justify-center rounded-full bg-brand-gradient text-sm font-bold text-white">{{ mb_substr($n, 0, 1) }}</span>
                        <span class="text-sm"><strong>{{ $n }}</strong><br><span class="text-ink-400">{{ $k }}</span></span>
                    </figcaption>
                </figure>
            @endforeach
        </div>
    </section>

    {{-- ================= CTA ================= --}}
    <section data-reveal class="relative overflow-hidden rounded-3xl bg-brand-gradient p-8 text-center text-white shadow-2xl shadow-fuchsia-500/30 sm:p-14">
        <div class="absolute -left-10 -top-10 h-48 w-48 animate-blob rounded-full bg-white/20 blur-2xl"></div>
        <h2 class="relative text-2xl font-extrabold sm:text-4xl">{{ $login ? 'Yuk lanjut belanja!' : 'Gabung dan mulai belanja' }}</h2>
        <p class="relative mx-auto mt-2 max-w-lg text-white/90">{{ $login ? 'Temukan produk favoritmu di katalog lengkap kami.' : 'Buat akun gratis untuk checkout, melacak pesanan, dan simpan alamat pengiriman.' }}</p>
        <div class="relative mt-6 flex flex-wrap justify-center gap-3">
            <a href="{{ $login ? route('shop') : route('register') }}" class="btn bg-white !px-8 !py-3 text-base text-ink-900 shadow-xl hover:-translate-y-0.5">{{ $login ? 'Ke katalog' : 'Daftar sekarang' }}</a>
            @unless ($login)<a href="{{ route('login') }}" class="btn border border-white/60 !px-8 !py-3 text-base text-white hover:bg-white/15">Sudah punya akun</a>@endunless
        </div>
    </section>
</div>
@endsection
