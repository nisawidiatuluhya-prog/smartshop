@extends('layouts.app')
@section('title', 'Pesanan saya')

@section('content')
<div class="mx-auto max-w-3xl px-4 py-6 sm:px-6 sm:py-8">
    <h1 class="mb-5 text-2xl font-extrabold">Pesanan saya</h1>

    @forelse ($orders as $o)
        <a href="{{ route('pesanan.show', $o->kode) }}" class="card mb-3 flex items-center justify-between gap-3 p-4 transition hover:-translate-y-0.5 hover:border-accent-200 hover:shadow-lg hover:shadow-accent-600/10">
            <div>
                <p class="font-bold">#{{ $o->kode }}</p>
                <p class="text-sm text-ink-500">{{ \Carbon\Carbon::parse($o->tanggal_order)->format('d M Y') }} &middot; {{ $o->metode_pembayaran }}</p>
            </div>
            <div class="text-right">
                <span class="rounded-full px-2.5 py-0.5 text-xs font-semibold {{ status_badge($o->status_pesanan) }}">{{ $o->status_pesanan }}</span>
                <p class="mt-1 font-bold">{{ rupiah($o->total_harga) }}</p>
            </div>
        </a>
    @empty
        <div class="card p-12 text-center">
            <p class="font-semibold">Belum ada pesanan</p>
            <a href="{{ route('shop') }}" class="btn-primary mt-4">Mulai belanja</a>
        </div>
    @endforelse
</div>
@endsection
