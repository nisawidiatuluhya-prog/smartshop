@extends('layouts.app')
@section('title', $product['nama_produk'])

@section('content')
<div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
    <nav class="mb-4 text-sm text-ink-500" aria-label="Breadcrumb">
        <a href="{{ route('home') }}" class="hover:text-ink-900">Home</a> /
        <a href="{{ route('shop', ['kategori' => $product['kategori_slug']]) }}" class="hover:text-ink-900">{{ $product['kategori'] }}</a> /
        <span class="text-ink-900">{{ $product['nama_produk'] }}</span>
    </nav>

    <div class="grid gap-8 md:grid-cols-2" x-data="productPage({{ $product['id_produk'] }}, {{ $product['stok'] }})">
        <x-product-image :product="$product" size="h-28 w-28" class="rounded-3xl border border-ink-200">
            @if ($product['diskon'] > 0)
                <span class="absolute left-4 top-4 rounded-lg bg-sale-100 px-3 py-1 text-sm font-bold text-sale-600">-{{ $product['diskon'] }}%</span>
            @endif
        </x-product-image>

        <div>
            <p class="text-sm text-ink-500">{{ $product['kategori'] }}
                @if ($product['flag_status']) <span class="ml-2 rounded-md bg-accent-100 px-2 py-0.5 text-xs font-semibold text-accent-700">{{ $product['flag_status'] }}</span> @endif
            </p>
            <h1 class="mt-1 text-2xl font-bold sm:text-3xl">{{ $product['nama_produk'] }}</h1>

            <div class="mt-4 flex items-baseline gap-3">
                <span class="text-3xl font-extrabold">{{ rupiah($product['harga_final']) }}</span>
                @if ($product['diskon'] > 0) <span class="text-ink-400 line-through">{{ rupiah($product['harga']) }}</span> @endif
            </div>

            <p class="mt-4 leading-relaxed text-ink-600">{{ $product['deskripsi'] }}</p>

            <dl class="mt-5 grid grid-cols-2 gap-3 text-sm">
                <div class="card p-3"><dt class="text-ink-500">Stok</dt><dd class="font-semibold">{{ $product['stok'] > 0 ? $product['stok'].' tersedia' : 'Habis' }}</dd></div>
                <div class="card p-3"><dt class="text-ink-500">Terjual</dt><dd class="font-semibold">{{ $product['terjual'] }}</dd></div>
            </dl>

            <div class="mt-6 flex flex-wrap items-center gap-4">
                <div class="flex items-center rounded-xl border border-ink-200 bg-white">
                    <button class="p-3 hover:bg-ink-100" @click="dec()" aria-label="Kurangi"><x-icon name="minus" class="h-4 w-4" /></button>
                    <span class="w-10 text-center font-semibold" x-text="qty"></span>
                    <button class="p-3 hover:bg-ink-100" @click="inc()" aria-label="Tambah"><x-icon name="plus" class="h-4 w-4" /></button>
                </div>
                <button class="btn-primary flex-1 sm:flex-none sm:px-10" @click="add()" {{ $product['stok'] < 1 ? 'disabled' : '' }}>
                    <x-icon name="bag" class="h-4 w-4" /> Add to cart
                </button>
            </div>
            <p class="mt-2 text-xs text-ink-400" x-show="qty >= stok" x-cloak>Jumlah maksimal sesuai stok.</p>
            <a href="{{ route('keranjang') }}" class="mt-5 inline-block text-sm font-medium text-accent-600 hover:underline">Lihat keranjang</a>
        </div>
    </div>

    @if (count($terkait))
        <section class="mt-14">
            <h2 class="mb-4 text-xl font-bold">Produk terkait</h2>
            <div class="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
                @foreach ($terkait as $p) <x-product-card :product="$p" /> @endforeach
            </div>
        </section>
    @endif
</div>
@endsection
