import Alpine from 'alpinejs';

window.Alpine = Alpine;

/* ------------------------------------------------------------------ *
 * Utilitas
 * ------------------------------------------------------------------ */
const rupiah = (n) => 'Rp ' + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const load = (key, fallback) => {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
};
const save = (key, value) => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage penuh / diblokir */ }
};
const SS = () => window.SS ?? { products: [], categories: [], couriers: [], rekening: {} };
const badge = (s) => ({
    'Menunggu Verifikasi': 'bg-amber-100 text-amber-800',
    'Diproses': 'bg-sky-100 text-sky-800',
    'Dikirim': 'bg-indigo-100 text-indigo-800',
    'Selesai': 'bg-emerald-100 text-emerald-800',
}[s] ?? 'bg-ink-100 text-ink-700');
const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const phoneOk = (v) => /^(\+62|62|0)8[0-9]{8,12}$/.test(v.replace(/[\s-]/g, ''));
window.rupiah = rupiah;
window.badge = badge;
window.tone = (jenis) => ({
    fashion: 'bg-rose-100 text-rose-500',
    kosmetik: 'bg-amber-100 text-amber-600',
    sepatu: 'bg-sky-100 text-sky-600',
    tas: 'bg-emerald-100 text-emerald-600',
}[jenis] ?? 'bg-ink-100 text-ink-500');

/* ------------------------------------------------------------------ *
 * Store global
 * ------------------------------------------------------------------ */
Alpine.store('toast', {
    msg: '', open: false, timer: null,
    show(msg) {
        this.msg = msg; this.open = true;
        clearTimeout(this.timer);
        this.timer = setTimeout(() => (this.open = false), 2600);
    },
});

// Keranjang disimpan di localStorage (kunci: ss_cart) -> [{id, qty}]
Alpine.store('cart', {
    items: load('ss_cart', []),
    persist() { save('ss_cart', this.items); },
    find(id) { return SS().products.find((p) => p.id_produk === id); },
    get count() { return this.items.reduce((a, i) => a + i.qty, 0); },
    get lines() {
        return this.items
            .map((i) => ({ ...this.find(i.id), qty: i.qty }))
            .filter((l) => l.id_produk);
    },
    get subtotal() { return this.lines.reduce((a, l) => a + l.harga_final * l.qty, 0); },
    add(id, qty = 1) {
        const p = this.find(id);
        if (!p) return;
        const row = this.items.find((i) => i.id === id);
        const next = Math.min((row?.qty ?? 0) + qty, p.stok);
        if (row) row.qty = next; else this.items.push({ id, qty: next });
        this.persist();
        Alpine.store('toast').show(`${p.nama_produk} masuk keranjang`);
    },
    inc(id) {
        const row = this.items.find((i) => i.id === id), p = this.find(id);
        if (row && p && row.qty < p.stok) { row.qty++; this.persist(); }
    },
    dec(id) {
        const row = this.items.find((i) => i.id === id);
        if (row && row.qty > 1) { row.qty--; this.persist(); }
    },
    remove(id) { this.items = this.items.filter((i) => i.id !== id); this.persist(); },
    clear() { this.items = []; this.persist(); },
});

/* ------------------------------------------------------------------ *
 * Komponen halaman customer
 * ------------------------------------------------------------------ */
Alpine.data('shopPage', () => ({
    kategori: [], min: '', max: '', flash: false, baru: false, sort: 'terlaris', q: '', filterOpen: false,
    init() {
        const url = new URLSearchParams(location.search);
        const slug = url.get('kategori');
        const cat = SS().categories.find((c) => c.slug === slug);
        if (cat) this.kategori = [cat.id_kategori];
        this.q = url.get('q') ?? '';
        if (url.get('flash')) this.flash = true;
    },
    prod(id) { return SS().products.find((p) => p.id_produk === id); },
    match(id) {
        const p = this.prod(id);
        if (this.kategori.length && !this.kategori.includes(p.id_kategori)) return false;
        if (this.min !== '' && p.harga_final < Number(this.min)) return false;
        if (this.max !== '' && p.harga_final > Number(this.max)) return false;
        if (this.flash && p.flag_status !== 'Flash Sale') return false;
        if (this.baru && p.flag_status !== 'New Arrival') return false;
        if (this.q && !p.nama_produk.toLowerCase().includes(this.q.toLowerCase())) return false;
        return true;
    },
    rank(id) {
        const p = this.prod(id);
        if (this.sort === 'terbaru') return 1000 - p.id_produk;
        if (this.sort === 'termurah') return p.harga_final;
        return 100000 - p.terjual; // terlaris
    },
    get count() { return SS().products.filter((p) => this.match(p.id_produk)).length; },
    reset() { this.kategori = []; this.min = ''; this.max = ''; this.flash = false; this.baru = false; this.q = ''; },
}));

Alpine.data('productPage', (id, stok) => ({
    id, stok, qty: 1,
    inc() { if (this.qty < this.stok) this.qty++; },
    dec() { if (this.qty > 1) this.qty--; },
    add() { Alpine.store('cart').add(this.id, this.qty); },
}));

// Checkout: validasi di browser, lalu form dikirim sungguhan ke server (POST /checkout)
Alpine.data('checkoutPage', (profile = {}) => ({
    f: { nama: profile.nama ?? '', telp: profile.telp ?? '', alamat: profile.alamat ?? '', kurir: profile.kurir || '', metode: profile.metode || 'COD' },
    err: {}, bukti: null, buktiNama: '', done: false,
    init() { if (!this.f.kurir) this.f.kurir = SS().couriers[0]?.kode ?? ''; },
    get courier() { return SS().couriers.find((c) => c.kode === this.f.kurir); },
    get ongkir() { return Alpine.store('cart').count ? this.courier?.tarif ?? 0 : 0; },
    get total() { return Alpine.store('cart').subtotal + this.ongkir; },
    pickFile(e) {
        const file = e.target.files[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) { this.err.bukti = 'File harus berupa gambar (JPG/PNG).'; return; }
        if (file.size > 3 * 1024 * 1024) { this.err.bukti = 'Ukuran gambar maksimal 3 MB.'; return; }
        delete this.err.bukti;
        this.buktiNama = file.name;
        const reader = new FileReader();
        reader.onload = () => (this.bukti = reader.result); // hanya pratinjau di browser
        reader.readAsDataURL(file);
    },
    validate() {
        const e = {};
        if (this.f.nama.trim().length < 3) e.nama = 'Nama minimal 3 karakter.';
        if (!phoneOk(this.f.telp)) e.telp = 'Nomor telepon tidak valid (contoh: 081234567890).';
        if (this.f.alamat.trim().length < 10) e.alamat = 'Alamat lengkap minimal 10 karakter.';
        if (this.f.metode === 'Transfer' && !this.bukti) e.bukti = 'Unggah bukti pembayaran terlebih dahulu.';
        if (!Alpine.store('cart').count) e.cart = 'Keranjang masih kosong.';
        this.err = e;
        return Object.keys(e).length === 0;
    },
    submit() {
        if (!this.validate()) return;
        // isi keranjang (id + jumlah) dikirim ke server; harga dihitung ulang di server
        this.$refs.items.value = JSON.stringify(Alpine.store('cart').items);
        this.done = true;
        this.$refs.form.submit();
    },
}));

// Halaman pelacakan: data pesanan datang dari database (lewat controller)
Alpine.data('trackingPage', (order) => ({
    order,
    get status() { return this.order.status_pesanan; },
    get catatan() { return this.order.tracking.catatan_kurir; },
    get subtotal() { return this.order.items.reduce((a, i) => a + i.harga_satuan * i.jumlah_beli, 0); },
}));

// Form login/daftar: validasi di browser dulu, lalu dikirim ke server (POST) yang memvalidasi ulang
Alpine.data('authForm', (type, old = {}) => ({
    type, show: false, loading: false, err: {},
    f: { nama: old.nama ?? '', email: old.email ?? '', telp: old.telp ?? '', password: '', password2: '' },
    submit() {
        const e = {};
        if (this.type === 'register') {
            if (this.f.nama.trim().length < 3) e.nama = 'Nama minimal 3 karakter.';
            if (!phoneOk(this.f.telp)) e.telp = 'Nomor telepon tidak valid (contoh: 081234567890).';
        }
        if (!emailOk(this.f.email)) e.email = 'Format email tidak valid.';
        if (this.f.password.length < 8) e.password = 'Kata sandi minimal 8 karakter.';
        if (this.type === 'register' && this.f.password2 !== this.f.password) e.password2 = 'Konfirmasi kata sandi tidak sama.';
        this.err = e;
        if (Object.keys(e).length) return;
        this.loading = true;
        this.$el.submit(); // kirim form asli ke Laravel
    },
}));

// Hitung mundur flash sale sampai tengah malam
Alpine.data('countdown', () => ({
    h: '00', m: '00', s: '00',
    init() {
        const pad = (n) => String(n).padStart(2, '0');
        const tick = () => {
            const end = new Date(); end.setHours(23, 59, 59, 999);
            const d = Math.max(0, end - new Date());
            this.h = pad(Math.floor(d / 3600000));
            this.m = pad(Math.floor(d / 60000) % 60);
            this.s = pad(Math.floor(d / 1000) % 60);
        };
        tick();
        setInterval(tick, 1000);
    },
}));

/* ------------------------------------------------------------------ *
 * Widget AI Assistant (jawaban pura-pura berdasarkan kata kunci)
 * ------------------------------------------------------------------ */
Alpine.data('aiWidget', () => ({
    open: false, input: '', typing: false,
    messages: [{ from: 'ai', text: 'Halo! Saya Smart AI Assistant. Mau cari outfit, sepatu, tas, atau kosmetik? Tanyakan saja.', picks: [] }],
    suggestions: ['Rekomendasi outfit santai', 'Sepatu untuk jalan-jalan', 'Tas untuk kuliah', 'Kosmetik pemula'],
    byCat(slug, n = 2) {
        return SS().products.filter((p) => p.kategori_slug === slug).sort((a, b) => b.terjual - a.terjual).slice(0, n);
    },
    reply(q) {
        const t = q.toLowerCase();
        const has = (...w) => w.some((x) => t.includes(x));
        const P = SS().products;
        if (has('outfit', 'baju', 'pakaian', 'kemeja', 'dress', 'gaya', 'ootd'))
            return { text: 'Untuk outfit santai yang tetap rapi, coba padukan satu atasan, sepatu, dan tas berikut:', picks: [...this.byCat('fashion', 1), ...this.byCat('sepatu', 1), ...this.byCat('tas', 1)] };
        if (has('sepatu', 'sneakers', 'sandal', 'sendal'))
            return { text: 'Ini sepatu dan sandal yang paling banyak dipilih pelanggan kami:', picks: this.byCat('sepatu', 3) };
        if (has('tas', 'ransel', 'totebag', 'selempang'))
            return { text: 'Pilihan tas favorit untuk kuliah, kerja, atau jalan-jalan:', picks: this.byCat('tas', 3) };
        if (has('kosmetik', 'makeup', 'skincare', 'lipstik', 'lip', 'serum', 'sunscreen', 'kulit'))
            return { text: 'Untuk perawatan dan makeup harian, saya sarankan:', picks: this.byCat('kosmetik', 3) };
        if (has('promo', 'diskon', 'sale', 'flash'))
            return { text: 'Sedang ada Flash Sale! Diskon sampai 30% untuk produk berikut:', picks: P.filter((p) => p.flag_status === 'Flash Sale').sort((a, b) => b.diskon - a.diskon).slice(0, 3) };
        if (has('murah', 'hemat', 'budget', 'terjangkau'))
            return { text: 'Produk dengan harga paling bersahabat saat ini:', picks: [...P].sort((a, b) => a.harga_final - b.harga_final).slice(0, 3) };
        if (has('baru', 'terbaru', 'new'))
            return { text: 'Koleksi terbaru yang baru saja masuk:', picks: P.filter((p) => p.flag_status === 'New Arrival').slice(0, 3) };
        if (has('halo', 'hai', 'hi ', 'selamat'))
            return { text: 'Halo juga! Ada yang bisa saya bantu carikan hari ini?', picks: [] };
        return { text: 'Maaf, saya belum paham maksudnya. Coba tanyakan tentang outfit, sepatu, tas, kosmetik, promo, atau produk murah ya.', picks: [] };
    },
    ask(q) {
        q = (q ?? this.input).trim();
        if (!q || this.typing) return;
        this.messages.push({ from: 'me', text: q, picks: [] });
        this.input = ''; this.typing = true; this.scroll();
        setTimeout(() => {
            this.messages.push({ from: 'ai', ...this.reply(q) });
            this.typing = false; this.scroll();
        }, 700);
    },
    scroll() { this.$nextTick(() => { const b = this.$refs.body; if (b) b.scrollTop = b.scrollHeight; }); },
}));

/* ------------------------------------------------------------------ *
 * Komponen admin
 * ------------------------------------------------------------------ */
Alpine.data('adminAi', () => ({
    q: '', answer: '', loading: false,
    samples: ['Berapa total sepatu yang terjual hari ini?', 'Produk apa yang paling laku?', 'Berapa pesanan menunggu verifikasi?'],
    ask(text) {
        if (text) this.q = text;
        const t = this.q.toLowerCase().trim();
        if (!t) return;
        const has = (...w) => w.some((x) => t.includes(x));
        this.loading = true; this.answer = '';
        setTimeout(() => {
            if (has('sepatu')) this.answer = 'Hari ini terjual 12 pasang sepatu dengan total Rp 1,8 juta. Sneakers Putih Classic menjadi yang terlaris.';
            else if (has('laku', 'terlaris', 'populer')) this.answer = 'Produk terlaris minggu ini adalah Totebag Kanvas (301 terjual), disusul Sunscreen SPF 50 (256) dan Kaos Oversize Basic (210).';
            else if (has('verifikasi', 'menunggu')) this.answer = 'Ada pesanan Transfer yang menunggu verifikasi. Buka tabel di bawah untuk memeriksa bukti bayarnya.';
            else if (has('penjualan', 'omzet', 'pendapatan', 'untung')) this.answer = 'Penjualan hari ini Rp 4,2 juta dari 18 pesanan, naik sekitar 14% dibanding kemarin.';
            else if (has('pesanan')) this.answer = 'Ada 18 pesanan baru hari ini: 11 Transfer dan 7 COD.';
            else if (has('stok')) this.answer = 'Stok paling tipis: Dress Midi Floral (18) dan Tas Selempang Elegan (20). Pertimbangkan untuk restock.';
            else this.answer = 'Maaf, saya belum bisa menjawab itu. Coba tanyakan tentang penjualan, sepatu, produk terlaris, stok, atau pesanan.';
            this.loading = false;
        }, 800);
    },
}));

Alpine.data('adminProducts', (products) => ({
    products, q: '', confirmId: null,
    get list() { return this.products.filter((p) => p.nama_produk.toLowerCase().includes(this.q.toLowerCase())); },
    get target() { return this.products.find((p) => p.id_produk === this.confirmId); },
    destroy() {
        const name = this.target.nama_produk;
        this.products = this.products.filter((p) => p.id_produk !== this.confirmId);
        this.confirmId = null;
        Alpine.store('toast').show(`"${name}" dihapus (hanya di tampilan).`);
    },
}));

Alpine.data('productForm', (p) => ({
    f: { nama: p?.nama_produk ?? '', kategori: p?.id_kategori ?? '', harga: p?.harga ?? '', stok: p?.stok ?? '', flag: p?.flag_status ?? '', deskripsi: p?.deskripsi ?? '' },
    err: {}, preview: null, edit: !!p,
    pick(e) {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => (this.preview = reader.result);
        reader.readAsDataURL(file);
    },
    submit() {
        const e = {};
        if (this.f.nama.trim().length < 3) e.nama = 'Nama produk minimal 3 karakter.';
        if (!this.f.kategori) e.kategori = 'Pilih kategori.';
        if (!(Number(this.f.harga) > 0)) e.harga = 'Harga harus lebih dari 0.';
        if (this.f.stok === '' || Number(this.f.stok) < 0) e.stok = 'Stok tidak boleh kosong atau negatif.';
        if (this.f.deskripsi.trim().length < 10) e.deskripsi = 'Deskripsi minimal 10 karakter.';
        this.err = e;
        if (Object.keys(e).length) return;
        Alpine.store('toast').show(this.edit ? 'Produk diperbarui (contoh tampilan).' : 'Produk ditambahkan (contoh tampilan).');
        setTimeout(() => (location.href = '/admin/produk'), 900);
    },
}));

Alpine.data('adminCategories', (list) => ({
    list, name: '', editId: null, err: '', confirmId: null,
    slug: (s) => s.toLowerCase().replace(/&/g, 'dan').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    save() {
        const n = this.name.trim();
        if (n.length < 3) { this.err = 'Nama kategori minimal 3 karakter.'; return; }
        this.err = '';
        if (this.editId) {
            const c = this.list.find((x) => x.id_kategori === this.editId);
            c.nama_kategori = n; c.slug = this.slug(n);
            Alpine.store('toast').show('Kategori diperbarui.');
        } else {
            const id = Math.max(0, ...this.list.map((x) => x.id_kategori)) + 1;
            this.list.push({ id_kategori: id, nama_kategori: n, slug: this.slug(n), jumlah_produk: 0 });
            Alpine.store('toast').show('Kategori ditambahkan.');
        }
        this.name = ''; this.editId = null;
    },
    edit(c) { this.editId = c.id_kategori; this.name = c.nama_kategori; this.$nextTick(() => this.$refs.input.focus()); },
    cancel() { this.editId = null; this.name = ''; this.err = ''; },
    get target() { return this.list.find((c) => c.id_kategori === this.confirmId); },
    destroy() {
        this.list = this.list.filter((c) => c.id_kategori !== this.confirmId);
        this.confirmId = null;
        Alpine.store('toast').show('Kategori dihapus (hanya di tampilan).');
    },
}));

Alpine.start();

// Animasi "muncul saat di-scroll": elemen dengan atribut data-reveal
document.documentElement.classList.add('js');
const revealAll = () => {
    const els = document.querySelectorAll('[data-reveal]:not(.is-visible)');
    if (!('IntersectionObserver' in window)) { els.forEach((el) => el.classList.add('is-visible')); return; }
    const io = new IntersectionObserver((entries) => entries.forEach((en) => {
        if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target); }
    }), { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    els.forEach((el) => io.observe(el));
};
document.addEventListener('DOMContentLoaded', revealAll);
