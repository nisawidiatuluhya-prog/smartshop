<?php

namespace Database\Seeders;

use App\Support\DummyData;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * Mengisi database dengan data awal (diambil dari DummyData supaya sama persis
 * dengan tampilan yang sudah kamu lihat). Jalankan: php artisan migrate:fresh --seed
 */
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Kategori
        foreach (DummyData::categories() as $c) {
            DB::table('categories')->insert([
                'id_kategori'   => $c['id_kategori'],
                'nama_kategori' => $c['nama_kategori'],
                'slug'          => $c['slug'],
            ]);
        }

        // 2. Pengguna: satu admin + 3 pelanggan contoh
        $sandiPelanggan = [2 => 'sari12345', 3 => 'budi12345', 4 => 'rina12345'];
        foreach (DummyData::users() as $u) {
            $admin = $u['role'] === 'Admin';
            DB::table('users')->insert([
                'id_user'  => $u['id_user'],
                'nama'     => $u['nama'],
                'email'    => strtolower($admin ? config('smartshop.admin_email') : $u['email']),
                'password' => Hash::make($admin ? config('smartshop.admin_password') : $sandiPelanggan[$u['id_user']]),
                'role'     => $u['role'],
                'no_telp'  => $u['no_telp'],
                'alamat'   => $u['alamat'],
            ]);
        }

        // 3. Produk
        foreach (DummyData::products() as $p) {
            DB::table('products')->insert([
                'id_produk'   => $p['id_produk'],
                'id_kategori' => $p['id_kategori'],
                'nama_produk' => $p['nama_produk'],
                'slug'        => $p['slug'],
                'harga'       => $p['harga'],
                'diskon'      => $p['diskon'],
                'stok'        => $p['stok'],
                'deskripsi'   => $p['deskripsi'],
                'gambar'      => $p['gambar'],
                'flag_status' => $p['flag_status'],
                'terjual'     => $p['terjual'],
                'ilustrasi'   => $p['ilustrasi'],
                'warna'       => json_encode($p['warna']),
                'latar'       => json_encode($p['latar']),
            ]);
        }

        // 4. Pesanan contoh + barang + riwayat pelacakan
        $catatan = [
            'Menunggu Verifikasi' => 'Pembayaran diterima, menunggu verifikasi admin.',
            'Diproses'            => 'Pesanan sedang dikemas oleh penjual.',
            'Dikirim'             => 'Paket diserahkan ke kurir dan sedang dalam perjalanan.',
            'Selesai'             => 'Paket telah diterima oleh yang bersangkutan.',
        ];

        foreach (DummyData::orders() as $o) {
            DB::table('orders')->insert([
                'id_order'          => $o['id_order'],
                'id_user'           => $o['id_user'],
                'kode'              => $o['kode'],
                'tanggal_order'     => $o['tanggal_order'],
                'total_harga'       => $o['total_harga'],
                'metode_pembayaran' => $o['metode_pembayaran'],
                'bukti_bayar'       => $o['bukti_bayar'],
                'status_pesanan'    => $o['status_pesanan'],
                'kurir'             => $o['kurir'],
                'ongkir'            => $o['ongkir'],
                'nama_penerima'     => $o['pelanggan'],
                'telepon'           => $o['telepon'],
                'alamat_pengiriman' => $o['alamat'],
            ]);

            foreach ($o['items'] as $i) {
                DB::table('order_items')->insert([
                    'id_item'      => $i['id_item'],
                    'id_order'     => $i['id_order'],
                    'id_produk'    => $i['id_produk'],
                    'nama_produk'  => $i['nama_produk'],
                    'jumlah_beli'  => $i['jumlah_beli'],
                    'harga_satuan' => $i['harga_satuan'],
                ]);
            }

            $last = count($o['riwayat']) - 1;
            foreach ($o['riwayat'] as $n => $r) {
                DB::table('shipping_tracking')->insert([
                    'id_order'       => $o['id_order'],
                    'status_terkini' => $r['status'],
                    'catatan_kurir'  => $n === $last ? $o['tracking']['catatan_kurir'] : $catatan[$r['status']],
                    'waktu_update'   => date('Y-m-d H:i:s', strtotime($r['waktu'])),
                ]);
            }
        }

        // 5. Contoh keranjang dan log AI
        foreach (DummyData::carts() as $c) {
            DB::table('carts')->insert($c);
        }
        foreach (DummyData::aiChatLog() as $l) {
            DB::table('ai_chat_log')->insert($l);
        }
    }
}
