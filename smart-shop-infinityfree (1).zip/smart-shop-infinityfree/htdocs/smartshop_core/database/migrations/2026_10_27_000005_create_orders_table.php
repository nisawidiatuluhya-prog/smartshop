<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id('id_order');
            $table->foreignId('id_user')->constrained('users', 'id_user')->cascadeOnDelete();
            $table->string('kode')->unique();                    // contoh: SS-0001 (dipakai di URL)
            $table->date('tanggal_order');
            $table->unsignedBigInteger('total_harga');
            $table->string('metode_pembayaran');                 // COD / Transfer
            $table->string('bukti_bayar')->nullable();
            $table->string('status_pesanan');                    // Menunggu Verifikasi / Diproses / Dikirim / Selesai
            $table->string('kurir');
            $table->unsignedInteger('ongkir')->default(0);
            $table->string('nama_penerima');
            $table->string('telepon', 20);
            $table->text('alamat_pengiriman');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
