<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Satu baris = satu pembaruan status (jadi riwayat). Baris terbaru = status terkini.
        Schema::create('shipping_tracking', function (Blueprint $table) {
            $table->id('id_tracking');
            $table->foreignId('id_order')->constrained('orders', 'id_order')->cascadeOnDelete();
            $table->string('status_terkini');
            $table->text('catatan_kurir')->nullable();
            $table->dateTime('waktu_update');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('shipping_tracking');
    }
};
