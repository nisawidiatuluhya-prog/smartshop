<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id('id_produk');
            $table->foreignId('id_kategori')->constrained('categories', 'id_kategori')->cascadeOnDelete();
            $table->string('nama_produk');
            $table->string('slug')->unique();
            $table->unsignedInteger('harga');
            $table->unsignedTinyInteger('diskon')->default(0);   // persen, untuk Flash Sale
            $table->unsignedInteger('stok')->default(0);
            $table->text('deskripsi');
            $table->string('gambar')->nullable();                // null = pakai ilustrasi/foto di public/images/produk
            $table->string('flag_status')->nullable();           // Flash Sale / New Arrival
            $table->unsignedInteger('terjual')->default(0);
            $table->string('ilustrasi')->default('tee');         // bentuk ilustrasi bawaan
            $table->json('warna');                               // [warna1, warna2]
            $table->json('latar');                               // [latar1, latar2]
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
