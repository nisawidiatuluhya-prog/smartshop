<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('carts', function (Blueprint $table) {
            $table->id('id_cart');
            $table->foreignId('id_user')->constrained('users', 'id_user')->cascadeOnDelete();
            $table->foreignId('id_produk')->constrained('products', 'id_produk')->cascadeOnDelete();
            $table->unsignedInteger('jumlah')->default(1);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('carts');
    }
};
