<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('order_items', function (Blueprint $table) {
            $table->id('id_item');
            $table->foreignId('id_order')->constrained('orders', 'id_order')->cascadeOnDelete();
            // nullable: kalau produk dihapus, riwayat pesanan tetap ada
            $table->foreignId('id_produk')->nullable()->constrained('products', 'id_produk')->nullOnDelete();
            $table->string('nama_produk');                       // salinan nama saat dibeli
            $table->unsignedInteger('jumlah_beli');
            $table->unsignedInteger('harga_satuan');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_items');
    }
};
