<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * users(id_user, nama, email, role, no_telp, alamat)
 * Tabel users bawaan Laravel (kolom "name") dibuang dulu, diganti yang sesuai ERD.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::dropIfExists('users');

        Schema::create('users', function (Blueprint $table) {
            $table->id('id_user');
            $table->string('nama');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('role')->default('Customer'); // Admin / Customer
            $table->string('no_telp', 20)->nullable();
            $table->text('alamat')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
