<?php

namespace App\Support;

use Illuminate\Support\Str;

/**
 * SUMBER DATA CONTOH TUNGGAL.
 * Nama field mengikuti rancangan database (ERD), jadi nanti tinggal diganti
 * dengan Eloquent, misalnya: Product::with('kategori')->get()->toArray().
 */
class DummyData
{
    public const STATUS = ['Menunggu Verifikasi', 'Diproses', 'Dikirim', 'Selesai'];

    public const REKENING = ['bank' => 'Bank BCA', 'nomor' => '1234 5678 90', 'atas_nama' => 'SMART SHOP INDONESIA'];

    public static function couriers(): array
    {
        return [
            ['kode' => 'jne',     'nama' => 'JNE Reguler',   'estimasi' => '2-3 hari', 'tarif' => 15000],
            ['kode' => 'jnt',     'nama' => 'J&T Express',   'estimasi' => '2-4 hari', 'tarif' => 18000],
            ['kode' => 'sicepat', 'nama' => 'SiCepat Halu',  'estimasi' => '3-5 hari', 'tarif' => 12000],
        ];
    }

    /** categories(id_kategori, nama_kategori, slug) */
    public static function categories(): array
    {
        return [
            ['id_kategori' => 1, 'nama_kategori' => 'Fashion',         'slug' => 'fashion',  'jenis' => 'fashion'],
            ['id_kategori' => 2, 'nama_kategori' => 'Kosmetik',        'slug' => 'kosmetik', 'jenis' => 'kosmetik'],
            ['id_kategori' => 3, 'nama_kategori' => 'Sepatu & Sandal', 'slug' => 'sepatu',   'jenis' => 'sepatu'],
            ['id_kategori' => 4, 'nama_kategori' => 'Tas',             'slug' => 'tas',      'jenis' => 'tas'],
        ];
    }

    /**
     * products(id_produk, id_kategori, nama_produk, harga, stok, deskripsi, gambar, flag_status)
     * Field tambahan untuk tampilan: slug, diskon, harga_final, terjual.
     */
    public static function products(): array
    {
        // [id, kategori, nama, harga, stok, flag, diskon%, terjual, deskripsi]
        $rows = [
            [1, 1, 'Kemeja Linen Putih',         189000, 25,  null,          0,  64,  'Kemeja linen adem dan ringan, cocok untuk kerja maupun santai. Tersedia ukuran S sampai XL.'],
            [2, 1, 'Kaos Oversize Basic',         99000, 80,  'Flash Sale',  15, 210, 'Kaos katun combed 24s yang lembut, potongan oversize yang nyaman dipadukan dengan apa saja.'],
            [3, 1, 'Dress Midi Floral',          259000, 18,  'New Arrival', 0,  12,  'Dress midi motif bunga dengan bahan jatuh dan tidak mudah kusut. Pas untuk acara santai.'],
            [4, 1, 'Celana Kulot Crinkle',       149000, 40,  'Flash Sale',  30, 143, 'Celana kulot crinkle pinggang karet, tidak perlu disetrika dan nyaman dipakai seharian.'],
            [5, 2, 'Lip Tint Matte Rose',         69000, 120, 'New Arrival', 0,  38,  'Lip tint matte warna rose yang tahan lama, ringan di bibir, tidak lengket.'],
            [6, 2, 'Serum Vitamin C 10%',        125000, 55,  'Flash Sale',  20, 187, 'Serum vitamin C 10% membantu mencerahkan kulit dan menyamarkan noda hitam. Aman untuk kulit sensitif.'],
            [7, 2, 'Sunscreen SPF 50 PA++++',     89000, 90,  null,          0,  256, 'Sunscreen gel ringan tanpa white cast, perlindungan maksimal dari sinar UVA dan UVB.'],
            [8, 2, 'Cushion Foundation Natural', 149000, 35,  null,          0,  97,  'Cushion dengan coverage natural dan hasil akhir seperti kulit sendiri. Sudah termasuk refill.'],
            [9, 3, 'Sneakers Putih Classic',     329000, 30,  'Flash Sale',  15, 175, 'Sneakers putih model klasik dengan sol empuk. Mudah dipadukan dengan outfit apa pun.'],
            [10, 3, 'Sandal Slide Nyaman',        99000, 70,  null,          0,  132, 'Sandal slide dengan sol anti slip dan bantalan empuk, nyaman dipakai di rumah atau jalan santai.'],
            [11, 3, 'Sepatu Lari Ringan',        459000, 22,  'New Arrival', 0,  29,  'Sepatu lari super ringan dengan midsole responsif dan upper yang breathable.'],
            [12, 3, 'Flat Shoes Kulit',          219000, 28,  null,          0,  58,  'Flat shoes dari kulit sintetis premium, tampilan rapi untuk ke kantor.'],
            [13, 4, 'Totebag Kanvas',             79000, 100, 'Flash Sale',  30, 301, 'Totebag kanvas tebal dengan kantong dalam berresleting. Muat laptop 14 inci.'],
            [14, 4, 'Ransel Urban Anti Air',     289000, 26,  'New Arrival', 0,  41,  'Ransel bahan anti air dengan kompartemen laptop dan port USB untuk mengisi daya.'],
            [15, 4, 'Sling Bag Mini',            159000, 45,  null,          0,  119, 'Sling bag mini praktis untuk membawa ponsel, dompet, dan kunci saat bepergian.'],
            [16, 4, 'Tas Selempang Elegan',      249000, 20,  null,          0,  74,  'Tas selempang kulit sintetis dengan tampilan elegan dan tali yang bisa diatur panjangnya.'],
        ];

        $kategori = collect(self::categories())->keyBy('id_kategori');

        // Tampilan ilustrasi per produk: [bentuk, warna1, warna2, latar1, latar2]
        $visual = [
            1  => ['shirt',    '#ffffff', '#cbd5e1', '#e0f2fe', '#bae6fd'],
            2  => ['tee',      '#fdba74', '#ea580c', '#fff7ed', '#fed7aa'],
            3  => ['dress',    '#f9a8d4', '#db2777', '#fdf2f8', '#fbcfe8'],
            4  => ['pants',    '#86efac', '#16a34a', '#ecfdf5', '#a7f3d0'],
            5  => ['lipstick', '#fb7185', '#be123c', '#fff1f2', '#fecdd3'],
            6  => ['serum',    '#fcd34d', '#ea580c', '#fffbeb', '#fde68a'],
            7  => ['tube',     '#e0f2fe', '#38bdf8', '#f0f9ff', '#bae6fd'],
            8  => ['compact',  '#f9a8d4', '#be185d', '#fdf4ff', '#f5d0fe'],
            9  => ['sneaker',  '#ffffff', '#cbd5e1', '#ede9fe', '#ddd6fe'],
            10 => ['slide',    '#5eead4', '#0d9488', '#f0fdfa', '#99f6e4'],
            11 => ['runner',   '#38bdf8', '#1d4ed8', '#eff6ff', '#bfdbfe'],
            12 => ['flat',     '#f5d0a9', '#b45309', '#fef3c7', '#fcd9a8'],
            13 => ['tote',     '#fef3c7', '#d6b370', '#ecfccb', '#bef264'],
            14 => ['backpack', '#818cf8', '#312e81', '#e0e7ff', '#c7d2fe'],
            15 => ['sling',    '#c4b5fd', '#7c3aed', '#f5f3ff', '#ddd6fe'],
            16 => ['shoulder', '#b45309', '#451a03', '#fff7ed', '#fed7aa'],
        ];

        return array_map(function ($r) use ($kategori, $visual) {
            [$id, $kat, $nama, $harga, $stok, $flag, $diskon, $terjual, $desk] = $r;
            $k = $kategori[$kat];
            $v = $visual[$id];

            return [
                'id_produk'     => $id,
                'id_kategori'   => $kat,
                'nama_produk'   => $nama,
                'slug'          => Str::slug($nama),
                'harga'         => $harga,
                'diskon'        => $diskon,
                'harga_final'   => (int) round($harga * (100 - $diskon) / 100),
                'stok'          => $stok,
                'deskripsi'     => $desk,
                'gambar'        => null, // null = pakai placeholder lokal
                'flag_status'   => $flag,
                'terjual'       => $terjual,
                'kategori'      => $k['nama_kategori'],
                'kategori_slug' => $k['slug'],
                'jenis'         => $k['jenis'],
                'ilustrasi'     => $v[0],
                'warna'         => [$v[1], $v[2]],
                'latar'         => [$v[3], $v[4]],
            ];
        }, $rows);
    }

    public static function product(int|string $idOrSlug): ?array
    {
        return collect(self::products())->first(
            fn ($p) => $p['slug'] === $idOrSlug || $p['id_produk'] === (int) $idOrSlug
        );
    }

    /** users(id_user, nama, email, role, no_telp, alamat) */
    public static function users(): array
    {
        return [
            ['id_user' => 1, 'nama' => 'Admin Smart Shop', 'email' => 'admin@smartshop.test', 'role' => 'Admin',    'no_telp' => '081200000001', 'alamat' => 'Jl. Gatot Subroto No. 10, Medan'],
            ['id_user' => 2, 'nama' => 'Sari Dewi',        'email' => 'sari@example.com',     'role' => 'Customer', 'no_telp' => '081234567801', 'alamat' => 'Jl. Sisingamangaraja No. 25, Medan'],
            ['id_user' => 3, 'nama' => 'Budi Santoso',     'email' => 'budi@example.com',     'role' => 'Customer', 'no_telp' => '081234567802', 'alamat' => 'Jl. Setia Budi No. 8, Medan'],
            ['id_user' => 4, 'nama' => 'Rina Marlina',     'email' => 'rina@example.com',     'role' => 'Customer', 'no_telp' => '081234567803', 'alamat' => 'Jl. Merak Jingga No. 3, Medan'],
        ];
    }

    /**
     * orders + order_items + shipping_tracking digabung jadi satu array per pesanan.
     * "kode" (SS-0001) dipakai di URL; id_order tetap ada sebagai acuan database.
     */
    public static function orders(): array
    {
        $users = collect(self::users())->keyBy('id_user');
        $kurir = collect(self::couriers())->keyBy('kode');

        // [id_order, id_user, tanggal, metode, status, kurir, [[id_produk, jumlah]...], catatan]
        $rows = [
            [1, 2, '2026-10-20', 'Transfer', 'Selesai',             'jne',     [[9, 1], [15, 1]], 'Paket telah diterima oleh yang bersangkutan.'],
            [2, 3, '2026-10-23', 'COD',      'Dikirim',             'jnt',     [[2, 2], [5, 1]],  'Paket sedang dibawa kurir menuju alamat Anda. Siapkan uang pas.'],
            [3, 4, '2026-10-24', 'COD',      'Diproses',            'sicepat', [[11, 1]],         'Pesanan sedang dikemas oleh penjual.'],
            [4, 2, '2026-10-25', 'Transfer', 'Menunggu Verifikasi', 'jne',     [[6, 1], [1, 1]],  'Menunggu admin memeriksa bukti pembayaran.'],
            [5, 3, '2026-10-25', 'Transfer', 'Menunggu Verifikasi', 'jnt',     [[13, 2]],         'Menunggu admin memeriksa bukti pembayaran.'],
        ];

        return array_map(function ($r) use ($users, $kurir) {
            [$id, $idUser, $tgl, $metode, $status, $kodeKurir, $barang, $catatan] = $r;
            $user = $users[$idUser];
            $kr   = $kurir[$kodeKurir];

            $items = [];
            $subtotal = 0;
            foreach ($barang as $i => [$idProduk, $jumlah]) {
                $p = self::product($idProduk);
                $items[] = [
                    'id_item'      => $id * 10 + $i + 1,
                    'id_order'     => $id,
                    'id_produk'    => $idProduk,
                    'nama_produk'  => $p['nama_produk'],
                    'jumlah_beli'  => $jumlah,
                    'harga_satuan' => $p['harga_final'],
                ];
                $subtotal += $p['harga_final'] * $jumlah;
            }

            // Riwayat: tiap status yang sudah dilewati mendapat satu baris
            $urutan  = $metode === 'COD' ? array_slice(self::STATUS, 1) : self::STATUS;
            $sampai  = array_search($status, $urutan, true);
            $riwayat = [];
            foreach (array_slice($urutan, 0, $sampai + 1) as $n => $st) {
                $riwayat[] = ['status' => $st, 'waktu' => date('d M Y, H:i', strtotime("$tgl 09:00 +".($n * 5).' hours'))];
            }

            return [
                'id_order'          => $id,
                'kode'              => sprintf('SS-%04d', $id),
                'id_user'           => $idUser,
                'pelanggan'         => $user['nama'],
                'telepon'           => $user['no_telp'],
                'alamat'            => $user['alamat'],
                'tanggal_order'     => $tgl,
                'metode_pembayaran' => $metode,
                'bukti_bayar'       => $metode === 'Transfer' ? sprintf('bukti-ss-%04d.jpg', $id) : null,
                'status_pesanan'    => $status,
                'kurir'             => $kr['nama'],
                'ongkir'            => $kr['tarif'],
                'total_harga'       => $subtotal + $kr['tarif'],
                'items'             => $items,
                // shipping_tracking(status_terkini, catatan_kurir, waktu_update)
                'tracking'          => ['status_terkini' => $status, 'catatan_kurir' => $catatan, 'waktu_update' => end($riwayat)['waktu']],
                'riwayat'           => $riwayat,
            ];
        }, $rows);
    }

    public static function order(string $kode): ?array
    {
        return collect(self::orders())->first(fn ($o) => strcasecmp($o['kode'], $kode) === 0);
    }

    public static function pendingOrders(): array
    {
        return array_values(array_filter(self::orders(), fn ($o) => $o['status_pesanan'] === 'Menunggu Verifikasi'));
    }

    /** carts(id_cart, id_user, id_produk, jumlah) - contoh struktur; keranjang asli ada di localStorage */
    public static function carts(): array
    {
        return [['id_cart' => 1, 'id_user' => 2, 'id_produk' => 2, 'jumlah' => 1]];
    }

    /** ai_chat_log(id_log, id_user, pertanyaan, jawaban, waktu) - contoh struktur */
    public static function aiChatLog(): array
    {
        return [['id_log' => 1, 'id_user' => 2, 'pertanyaan' => 'Rekomendasi outfit santai?', 'jawaban' => 'Coba kaos oversize + celana kulot.', 'waktu' => '2026-10-25 10:12:00']];
    }

    public static function dashboardStats(): array
    {
        return [
            'penjualan_hari_ini' => 4200000,
            'pesanan_baru'       => 18,
            'barang_laku'        => 43,
            'sepatu_terjual'     => 12,
            'omzet_sepatu'       => 1800000,
        ];
    }

    /** Data laporan 7 hari terakhir (contoh). */
    public static function salesReport(): array
    {
        return [
            ['tanggal' => '2026-10-19', 'pesanan' => 11, 'barang' => 27, 'pendapatan' => 2850000],
            ['tanggal' => '2026-10-20', 'pesanan' => 14, 'barang' => 35, 'pendapatan' => 3475000],
            ['tanggal' => '2026-10-21', 'pesanan' => 9,  'barang' => 21, 'pendapatan' => 2120000],
            ['tanggal' => '2026-10-22', 'pesanan' => 16, 'barang' => 38, 'pendapatan' => 3960000],
            ['tanggal' => '2026-10-23', 'pesanan' => 13, 'barang' => 31, 'pendapatan' => 3240000],
            ['tanggal' => '2026-10-24', 'pesanan' => 20, 'barang' => 49, 'pendapatan' => 5180000],
            ['tanggal' => '2026-10-25', 'pesanan' => 18, 'barang' => 43, 'pendapatan' => 4200000],
        ];
    }
}
