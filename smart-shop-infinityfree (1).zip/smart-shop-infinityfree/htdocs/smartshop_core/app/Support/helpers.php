<?php

if (! function_exists('rupiah')) {
    /** Format angka ke Rupiah: 150000 => "Rp 150.000" (satu-satunya helper harga). */
    function rupiah(int|float $angka): string
    {
        return 'Rp ' . number_format($angka, 0, ',', '.');
    }
}

if (! function_exists('status_badge')) {
    /** Kelas warna badge untuk status pesanan (dipakai di Blade). */
    function status_badge(string $status): string
    {
        return match ($status) {
            'Menunggu Verifikasi' => 'bg-amber-100 text-amber-800',
            'Diproses'            => 'bg-sky-100 text-sky-800',
            'Dikirim'             => 'bg-indigo-100 text-indigo-800',
            'Selesai'             => 'bg-emerald-100 text-emerald-800',
            default               => 'bg-ink-100 text-ink-700',
        };
    }
}
