<?php

namespace App\Support;

use App\Models\Category;
use App\Models\Product;

/**
 * Membaca katalog dari DATABASE, dengan bentuk array yang sama seperti DummyData
 * sehingga halaman-halaman (view) tidak perlu diubah.
 */
class Catalog
{
    public static function categories(): array
    {
        return Category::orderBy('id_kategori')->get()->map(fn ($c) => [
            'id_kategori'   => (int) $c->id_kategori,
            'nama_kategori' => $c->nama_kategori,
            'slug'          => $c->slug,
            'jenis'         => $c->slug,
        ])->all();
    }

    public static function products(): array
    {
        return Product::with('category')->orderBy('id_produk')->get()
            ->map(fn ($p) => self::map($p))->all();
    }

    public static function product(int|string $idOrSlug): ?array
    {
        $q = Product::with('category');
        $p = is_numeric($idOrSlug) ? $q->find((int) $idOrSlug) : $q->where('slug', $idOrSlug)->first();

        return $p ? self::map($p) : null;
    }

    private static function map(Product $p): array
    {
        return [
            'id_produk'     => (int) $p->id_produk,
            'id_kategori'   => (int) $p->id_kategori,
            'nama_produk'   => $p->nama_produk,
            'slug'          => $p->slug,
            'harga'         => (int) $p->harga,
            'diskon'        => (int) $p->diskon,
            'harga_final'   => (int) round($p->harga * (100 - $p->diskon) / 100),
            'stok'          => (int) $p->stok,
            'deskripsi'     => $p->deskripsi,
            'gambar'        => $p->gambar,
            'flag_status'   => $p->flag_status,
            'terjual'       => (int) $p->terjual,
            'kategori'      => $p->category->nama_kategori ?? '-',
            'kategori_slug' => $p->category->slug ?? '',
            'jenis'         => $p->category->slug ?? '',
            'ilustrasi'     => $p->ilustrasi,
            'warna'         => $p->warna ?? ['#cbd5e1', '#64748b'],
            'latar'         => $p->latar ?? ['#f1f5f9', '#e2e8f0'],
        ];
    }
}
