<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class Order extends Model
{
    protected $table = 'orders';
    protected $primaryKey = 'id_order';
    public $timestamps = false;
    protected $guarded = [];

    /** Catatan kurir bawaan untuk tiap status. */
    public const CATATAN = [
        'Menunggu Verifikasi' => 'Pembayaran diterima, menunggu verifikasi admin.',
        'Diproses'            => 'Pesanan sedang dikemas oleh penjual.',
        'Dikirim'             => 'Paket diserahkan ke kurir dan sedang dalam perjalanan.',
        'Selesai'             => 'Paket telah diterima oleh yang bersangkutan.',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class, 'id_order', 'id_order');
    }

    public function tracking()
    {
        return $this->hasMany(ShippingTracking::class, 'id_order', 'id_order')
            ->orderBy('waktu_update')->orderBy('id_tracking');
    }

    /** Ubah status + catat riwayatnya di tabel shipping_tracking. */
    public function ubahStatus(string $status, ?string $catatan = null): void
    {
        $this->update(['status_pesanan' => $status]);
        $this->tracking()->create([
            'status_terkini' => $status,
            'catatan_kurir'  => $catatan ?? self::CATATAN[$status] ?? '',
            'waktu_update'   => now(),
        ]);
    }

    /** URL gambar bukti bayar bila filenya benar-benar ada. */
    public function buktiUrl(): ?string
    {
        if ($this->bukti_bayar && file_exists(public_path($this->bukti_bayar))) {
            return asset($this->bukti_bayar);
        }

        return null;
    }

    /** Bentuk array yang dipakai halaman pelacakan dan halaman admin. */
    public function tampil(): array
    {
        $this->loadMissing(['items', 'tracking']);
        $last = $this->tracking->last();
        $format = fn ($t) => Carbon::parse($t)->format('d M Y, H:i');

        return [
            'id_order'          => (int) $this->id_order,
            'kode'              => $this->kode,
            'pelanggan'         => $this->nama_penerima,
            'telepon'           => $this->telepon,
            'alamat'            => $this->alamat_pengiriman,
            'tanggal_order'     => (string) $this->tanggal_order,
            'metode_pembayaran' => $this->metode_pembayaran,
            'bukti_bayar'       => $this->bukti_bayar,
            'bukti_url'         => $this->buktiUrl(),
            'status_pesanan'    => $this->status_pesanan,
            'kurir'             => $this->kurir,
            'ongkir'            => (int) $this->ongkir,
            'total_harga'       => (int) $this->total_harga,
            'items'             => $this->items->map(fn ($i) => [
                'nama_produk'  => $i->nama_produk,
                'jumlah_beli'  => (int) $i->jumlah_beli,
                'harga_satuan' => (int) $i->harga_satuan,
            ])->all(),
            'tracking'          => [
                'status_terkini' => $this->status_pesanan,
                'catatan_kurir'  => $last->catatan_kurir ?? '',
                'waktu_update'   => $last ? $format($last->waktu_update) : '',
            ],
            'riwayat'           => $this->tracking->map(fn ($t) => [
                'status' => $t->status_terkini,
                'waktu'  => $format($t->waktu_update),
            ])->values()->all(),
        ];
    }
}
