<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShippingTracking extends Model
{
    protected $table = 'shipping_tracking';
    protected $primaryKey = 'id_tracking';
    public $timestamps = false;
    protected $guarded = [];
}
