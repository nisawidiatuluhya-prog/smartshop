<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'id_produk';
    public $timestamps = false;
    protected $guarded = [];

    protected function casts(): array
    {
        return ['warna' => 'array', 'latar' => 'array'];
    }

    public function category()
    {
        return $this->belongsTo(Category::class, 'id_kategori', 'id_kategori');
    }
}
