<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AiChatLog extends Model
{
    protected $table = 'ai_chat_log';
    protected $primaryKey = 'id_log';
    public $timestamps = false;
    protected $guarded = [];
}
