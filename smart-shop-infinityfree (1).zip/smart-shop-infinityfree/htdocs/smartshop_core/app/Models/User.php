<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    protected $table = 'users';
    protected $primaryKey = 'id_user';
    public $timestamps = false;

    protected $fillable = ['nama', 'email', 'password', 'role', 'no_telp', 'alamat'];
    protected $hidden = ['password'];

    protected function casts(): array
    {
        return ['password' => 'hashed']; // otomatis di-hash saat disimpan
    }

    public function orders()
    {
        return $this->hasMany(Order::class, 'id_user', 'id_user');
    }
}
