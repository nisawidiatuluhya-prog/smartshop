<?php

namespace App\Http\Controllers;

use App\Support\Catalog;

class ShopController extends Controller
{
    public function home()
    {
        $products = collect(Catalog::products());

        return view('home', [
            'categories' => Catalog::categories(),
            'flashSale'  => $products->where('flag_status', 'Flash Sale')->take(4)->values()->all(),
            'unggulan'   => $products->sortByDesc('terjual')->take(4)->values()->all(),
            'baru'       => $products->where('flag_status', 'New Arrival')->take(4)->values()->all(),
            // satu produk wakil per kategori (untuk gambar kartu kategori)
            'wakil'      => $products->groupBy('id_kategori')->map(fn ($g) => $g->sortByDesc('terjual')->first())->all(),
        ]);
    }

    public function index()
    {
        return view('shop', [
            'categories' => Catalog::categories(),
            'products'   => Catalog::products(),
        ]);
    }

    public function show(string $slug)
    {
        $product = Catalog::product($slug);
        abort_if(! $product, 404);

        $terkait = collect(Catalog::products())
            ->where('id_kategori', $product['id_kategori'])
            ->where('id_produk', '!=', $product['id_produk'])
            ->take(4)->values()->all();

        return view('product', compact('product', 'terkait'));
    }
}
