<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Support\DummyData;

class CartController extends Controller
{
    public function cart()
    {
        return view('cart');
    }

    public function checkout()
    {
        // Isi otomatis nama/telepon/alamat dari akun yang sedang masuk (tabel users)
        $sesi = session('smartshop.user');
        $akun = $sesi ? User::find($sesi['id_user']) : null;

        return view('checkout', [
            'profile'  => [
                'nama'   => old('nama', $akun->nama ?? ''),
                'telp'   => old('telp', $akun->no_telp ?? ''),
                'alamat' => old('alamat', $akun->alamat ?? ''),
                'kurir'  => old('kurir', ''),
                'metode' => old('metode', 'COD'),
            ],
            'couriers' => DummyData::couriers(),
            'rekening' => DummyData::REKENING,
        ]);
    }
}
