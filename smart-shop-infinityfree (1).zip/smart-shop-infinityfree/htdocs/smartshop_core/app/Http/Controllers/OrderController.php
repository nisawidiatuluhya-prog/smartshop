<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Support\DummyData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class OrderController extends Controller
{
    private const MSG = [
        'nama.required'        => 'Nama penerima wajib diisi.',
        'nama.min'             => 'Nama penerima minimal 3 karakter.',
        'telp.required'        => 'Nomor telepon wajib diisi.',
        'telp.regex'           => 'Nomor telepon tidak valid (contoh: 081234567890).',
        'alamat.required'      => 'Alamat lengkap wajib diisi.',
        'alamat.min'           => 'Alamat lengkap minimal 10 karakter.',
        'kurir.required'       => 'Pilih kurir pengiriman.',
        'kurir.in'             => 'Kurir tidak valid.',
        'metode.required'      => 'Pilih metode pembayaran.',
        'metode.in'            => 'Metode pembayaran tidak valid.',
        'items.required'       => 'Keranjang masih kosong.',
        'items.json'           => 'Data keranjang tidak valid.',
        'bukti.required_if'    => 'Unggah bukti pembayaran untuk transfer bank.',
        'bukti.image'          => 'Bukti pembayaran harus berupa gambar (JPG/PNG).',
        'bukti.max'            => 'Ukuran bukti pembayaran maksimal 3 MB.',
    ];

    /** Daftar pesanan milik pelanggan yang sedang masuk. */
    public function index()
    {
        $u = session('smartshop.user');
        $orders = Order::where('id_user', $u['id_user'])->orderByDesc('id_order')->get();

        return view('orders-list', ['orders' => $orders]);
    }

    /** Buat pesanan dari checkout dan simpan ke database. */
    public function store(Request $request)
    {
        $u = session('smartshop.user');

        $data = $request->validate([
            'nama'   => ['required', 'min:3', 'max:80'],
            'telp'   => ['required', 'regex:/^(\+62|62|0)8[0-9]{8,12}$/'],
            'alamat' => ['required', 'min:10', 'max:500'],
            'kurir'  => ['required', 'in:'.implode(',', array_column(DummyData::couriers(), 'kode'))],
            'metode' => ['required', 'in:COD,Transfer'],
            'items'  => ['required', 'json'],
            'bukti'  => ['required_if:metode,Transfer', 'nullable', 'image', 'max:3072'],
        ], self::MSG);

        // Gabungkan barang yang sama: [id_produk => jumlah]
        $baris = [];
        foreach ((array) json_decode($data['items'], true) as $it) {
            $id = (int) ($it['id'] ?? 0);
            $qty = (int) ($it['qty'] ?? 0);
            if ($id > 0 && $qty > 0) {
                $baris[$id] = ($baris[$id] ?? 0) + $qty;
            }
        }
        if (! $baris) {
            throw ValidationException::withMessages(['items' => 'Keranjang masih kosong.']);
        }

        $kurir = collect(DummyData::couriers())->firstWhere('kode', $data['kurir']);

        $order = DB::transaction(function () use ($baris, $data, $kurir, $request, $u) {
            $produk = Product::whereIn('id_produk', array_keys($baris))->get()->keyBy('id_produk');

            $subtotal = 0;
            $lines = [];
            foreach ($baris as $id => $qty) {
                $p = $produk->get($id);
                if (! $p) {
                    throw ValidationException::withMessages(['items' => 'Ada produk yang sudah tidak tersedia. Periksa keranjangmu.']);
                }
                if ($qty > $p->stok) {
                    throw ValidationException::withMessages(['items' => "Stok \"{$p->nama_produk}\" tidak cukup (tersisa {$p->stok})."]);
                }
                $harga = (int) round($p->harga * (100 - $p->diskon) / 100);
                $subtotal += $harga * $qty;
                $lines[] = [$p, $qty, $harga];
            }

            // Simpan bukti bayar (hanya untuk Transfer) ke public/uploads/bukti
            $bukti = null;
            if ($data['metode'] === 'Transfer' && $request->hasFile('bukti')) {
                $file = $request->file('bukti');
                $nama = 'bukti-'.time().'-'.Str::random(6).'.'.$file->extension();
                $file->move(public_path('uploads/bukti'), $nama);
                $bukti = 'uploads/bukti/'.$nama;
            }

            $status = $data['metode'] === 'Transfer' ? 'Menunggu Verifikasi' : 'Diproses';

            $order = Order::create([
                'id_user'           => $u['id_user'],
                'kode'              => 'TMP'.Str::random(8), // diganti setelah id_order diketahui
                'tanggal_order'     => now()->toDateString(),
                'total_harga'       => $subtotal + $kurir['tarif'],
                'metode_pembayaran' => $data['metode'],
                'bukti_bayar'       => $bukti,
                'status_pesanan'    => $status,
                'kurir'             => $kurir['nama'],
                'ongkir'            => $kurir['tarif'],
                'nama_penerima'     => $data['nama'],
                'telepon'           => $data['telp'],
                'alamat_pengiriman' => $data['alamat'],
            ]);
            $order->update(['kode' => sprintf('SS-%04d', $order->id_order)]);

            foreach ($lines as [$p, $qty, $harga]) {
                $order->items()->create([
                    'id_produk'    => $p->id_produk,
                    'nama_produk'  => $p->nama_produk,
                    'jumlah_beli'  => $qty,
                    'harga_satuan' => $harga,
                ]);
                $p->decrement('stok', $qty);
                $p->increment('terjual', $qty);
            }

            $order->tracking()->create([
                'status_terkini' => $status,
                'catatan_kurir'  => $status === 'Diproses' ? 'Pesanan COD diterima dan sedang dikemas.' : Order::CATATAN[$status],
                'waktu_update'   => now(),
            ]);

            // Simpan alamat & telepon ke profil supaya checkout berikutnya terisi otomatis
            User::where('id_user', $u['id_user'])->update(['no_telp' => $data['telp'], 'alamat' => $data['alamat']]);

            return $order;
        });

        return redirect()->route('pesanan.show', $order->kode)
            ->with('status', 'Pesanan berhasil dibuat! Terima kasih.')
            ->with('order_baru', true);
    }

    /** Halaman pelacakan. Pelanggan hanya bisa melihat pesanannya sendiri; admin boleh semua. */
    public function show(string $kode)
    {
        $u = session('smartshop.user');

        if (! $u) {
            session()->put('url.intended', request()->fullUrl());

            return redirect()->route('login')->with('error', 'Masuk dulu untuk melihat pesanan.');
        }

        $order = Order::with(['items', 'tracking'])->where('kode', strtoupper($kode))->first();
        abort_if(! $order, 404);
        abort_if($u['role'] === 'Customer' && (int) $order->id_user !== (int) $u['id_user'], 403, 'Ini bukan pesananmu.');

        return view('order-tracking', ['kode' => $order->kode, 'order' => $order->tampil()]);
    }
}
