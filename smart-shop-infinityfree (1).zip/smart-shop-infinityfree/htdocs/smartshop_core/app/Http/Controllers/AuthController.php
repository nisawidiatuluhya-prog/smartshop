<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    private const MSG = [
        'nama.required'      => 'Nama wajib diisi.',
        'nama.min'           => 'Nama minimal 3 karakter.',
        'email.required'     => 'Email wajib diisi.',
        'email.email'        => 'Format email tidak valid.',
        'telp.required'      => 'Nomor telepon wajib diisi.',
        'telp.regex'         => 'Nomor telepon tidak valid (contoh: 081234567890).',
        'password.required'  => 'Kata sandi wajib diisi.',
        'password.min'       => 'Kata sandi minimal 8 karakter.',
        'password.confirmed' => 'Konfirmasi kata sandi tidak sama.',
    ];

    /** Simpan data ringkas pengguna ke session (tanda "sudah masuk"). */
    private function masuk(Request $request, User $user): void
    {
        $request->session()->regenerate();
        $request->session()->put('smartshop.user', [
            'id_user' => $user->id_user,
            'nama'    => $user->nama,
            'email'   => $user->email,
            'role'    => $user->role,
        ]);
    }

    /** Cari pengguna di tabel users berdasarkan email dan role. */
    private function cari(string $email, string $role): ?User
    {
        return User::where('email', strtolower(trim($email)))->where('role', $role)->first();
    }

    // ---------- Pelanggan ----------
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'email'    => ['required', 'email'],
            'password' => ['required', 'min:8'],
        ], self::MSG);

        $user = $this->cari($data['email'], 'Customer');

        if (! $user || ! Hash::check($data['password'], $user->password)) {
            return back()->withErrors(['email' => 'Email atau kata sandi salah.'])->onlyInput('email');
        }

        $this->masuk($request, $user);

        return redirect()->intended(route('home'))->with('status', 'Selamat datang, '.$user->nama.'!');
    }

    public function showRegister()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'nama'     => ['required', 'min:3', 'max:60'],
            'email'    => ['required', 'email', 'max:100'],
            'telp'     => ['required', 'regex:/^(\+62|62|0)8[0-9]{8,12}$/'],
            'password' => ['required', 'min:8', 'confirmed'],
        ], self::MSG);

        if (User::where('email', strtolower(trim($data['email'])))->exists()) {
            return back()->withErrors(['email' => 'Email ini sudah terdaftar. Silakan masuk.'])->onlyInput('nama', 'email', 'telp');
        }

        $user = User::create([
            'nama'     => $data['nama'],
            'email'    => strtolower(trim($data['email'])),
            'password' => $data['password'], // di-hash otomatis oleh model User
            'role'     => 'Customer',
            'no_telp'  => $data['telp'],
        ]);

        $this->masuk($request, $user);

        return redirect()->route('home')->with('status', 'Akun berhasil dibuat. Selamat berbelanja, '.$user->nama.'!');
    }

    // ---------- Admin (akun role "Admin" di tabel users; diisi seeder dari config/smartshop.php) ----------
    public function showAdminLogin()
    {
        return view('admin.login');
    }

    public function adminLogin(Request $request)
    {
        $data = $request->validate([
            'email'    => ['required', 'email'],
            'password' => ['required'],
        ], self::MSG);

        $admin = $this->cari($data['email'], 'Admin');

        if (! $admin || ! Hash::check($data['password'], $admin->password)) {
            return back()->withErrors(['email' => 'Email atau kata sandi admin salah.'])->onlyInput('email');
        }

        $this->masuk($request, $admin);

        return redirect()->route('admin.dashboard');
    }

    public function logout(Request $request)
    {
        $admin = ($request->session()->get('smartshop.user')['role'] ?? null) === 'Admin';
        $request->session()->forget('smartshop.user');
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return $admin ? redirect()->route('admin.login') : redirect()->route('home')->with('status', 'Kamu sudah keluar.');
    }
}
