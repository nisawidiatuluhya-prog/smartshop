<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Support\Catalog;
use App\Support\DummyData;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Str;

class AdminController extends Controller
{
    private function thumb(array $p): string
    {
        return Blade::render('<x-product-image :product="$p" class="h-full w-full" />', ['p' => $p]);
    }

    public function dashboard()
    {
        // Ringkasan HARI INI, dihitung dari tabel orders
        $orders = Order::with('items')->where('tanggal_order', now()->toDateString())->get();
        $items = $orders->flatMap(fn ($o) => $o->items);
        $sepatu = Product::whereIn('id_kategori', Category::where('slug', 'sepatu')->pluck('id_kategori'))->pluck('id_produk')->all();

        $stats = [
            'penjualan_hari_ini' => (int) $orders->sum('total_harga'),
            'pesanan_baru'       => $orders->count(),
            'barang_laku'        => (int) $items->sum('jumlah_beli'),
            'sepatu_terjual'     => (int) $items->whereIn('id_produk', $sepatu)->sum('jumlah_beli'),
        ];

        $pending = Order::with(['items', 'tracking'])
            ->where('status_pesanan', 'Menunggu Verifikasi')->where('metode_pembayaran', 'Transfer')
            ->orderBy('id_order')->get()->map(fn ($o) => $o->tampil())->all();

        return view('admin.dashboard', compact('stats', 'pending'));
    }

    public function products()
    {
        $products = array_map(fn ($p) => $p + ['thumb' => $this->thumb($p)], Catalog::products());

        return view('admin.products.index', ['products' => $products]);
    }

    public function productForm(?int $id = null)
    {
        $product = $id ? Catalog::product($id) : null;
        abort_if($id && ! $product, 404);

        return view('admin.products.form', ['product' => $product, 'categories' => Catalog::categories()]);
    }

    public function categories()
    {
        $hitung = collect(Catalog::products())->countBy('id_kategori');
        $list = array_map(fn ($c) => $c + ['jumlah_produk' => $hitung[$c['id_kategori']] ?? 0], Catalog::categories());

        return view('admin.categories', ['categories' => $list]);
    }

    // ---------- Produk ----------
    private function uniqueSlug(string $nama, ?int $ignoreId = null): string
    {
        $base = Str::slug($nama) ?: 'produk';
        $slug = $base;
        $i = 2;
        while (Product::where('slug', $slug)
            ->when($ignoreId, fn ($q) => $q->where('id_produk', '!=', $ignoreId))->exists()) {
            $slug = $base.'-'.$i++;
        }
        return $slug;
    }

    private function hapusFoto(?string $path): void
    {
        // Hanya hapus foto hasil unggahan admin
        if ($path && str_starts_with($path, 'images/produk/upload-') && is_file(public_path($path))) {
            @unlink(public_path($path));
        }
    }

    private function productSave(Request $request, ?Product $product)
    {
        $data = $request->validate([
            'id_kategori' => ['required', 'exists:categories,id_kategori'],
            'nama_produk' => ['required', 'string', 'max:255'],
            'harga'       => ['required', 'integer', 'min:0'],
            'diskon'      => ['nullable', 'integer', 'between:0,100'],
            'stok'        => ['required', 'integer', 'min:0'],
            'deskripsi'   => ['required', 'string'],
            'flag_status' => ['nullable', 'in:Flash Sale,New Arrival'],
            'foto'        => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ], [
            'required' => ':attribute wajib diisi.',
            'image'    => 'File harus berupa gambar.',
            'mimes'    => 'Format foto harus JPG, PNG, atau WEBP.',
            'max'      => 'Ukuran foto maksimal 2 MB.',
        ]);

        $values = [
            'id_kategori' => $data['id_kategori'],
            'nama_produk' => $data['nama_produk'],
            'slug'        => $this->uniqueSlug($data['nama_produk'], $product?->id_produk),
            'harga'       => $data['harga'],
            'diskon'      => $data['diskon'] ?? 0,
            'stok'        => $data['stok'],
            'deskripsi'   => $data['deskripsi'],
            'flag_status' => $data['flag_status'] ?? null,
        ];

        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $nama = 'upload-'.Str::random(12).'.'.$file->extension();
            $file->move(public_path('images/produk'), $nama);
            $values['gambar'] = 'images/produk/'.$nama;
            if ($product) {
                $this->hapusFoto($product->gambar);
            }
        }

        if (! $product) {
            // Nilai bawaan untuk produk baru
            $values += [
                'ilustrasi' => 'tee',
                'warna'     => ['#1e3a8a', '#3b82f6'],
                'latar'     => ['#e0e7ff', '#c7d2fe'],
                'terjual'   => 0,
            ];
            Product::unguarded(fn () => Product::create($values));
            $pesan = "Produk \"{$values['nama_produk']}\" ditambahkan.";
        } else {
            Product::unguarded(fn () => $product->update($values));
            $pesan = "Produk \"{$values['nama_produk']}\" diperbarui.";
        }

        return redirect()->route('admin.produk')->with('status', $pesan);
    }

    public function productStore(Request $request)
    {
        return $this->productSave($request, null);
    }

    public function productUpdate(Request $request, int $id)
    {
        return $this->productSave($request, Product::findOrFail($id));
    }

    public function productDestroy(int $id)
    {
        $product = Product::findOrFail($id);

        try {
            $foto = $product->gambar;
            $nama = $product->nama_produk;
            $product->delete();
            $this->hapusFoto($foto);
        } catch (QueryException $e) {
            return back()->with('error', 'Produk tidak bisa dihapus karena sudah ada di pesanan pelanggan.');
        }

        return redirect()->route('admin.produk')->with('status', "Produk \"{$nama}\" dihapus.");
    }

    // ---------- Kategori ----------
    public function categoryStore(Request $request)
    {
        $data = $request->validate(['nama_kategori' => ['required', 'string', 'max:100']],
            ['nama_kategori.required' => 'Nama kategori wajib diisi.']);

        $slug = Str::slug($data['nama_kategori']);
        if (Category::where('slug', $slug)->exists()) {
            return back()->withInput()->with('error', 'Kategori dengan nama itu sudah ada.');
        }

        Category::unguarded(fn () => Category::create(['nama_kategori' => $data['nama_kategori'], 'slug' => $slug]));

        return back()->with('status', "Kategori \"{$data['nama_kategori']}\" ditambahkan.");
    }

    public function categoryUpdate(Request $request, int $id)
    {
        $kategori = Category::findOrFail($id);
        $data = $request->validate(['nama_kategori' => ['required', 'string', 'max:100']],
            ['nama_kategori.required' => 'Nama kategori wajib diisi.']);

        $slug = Str::slug($data['nama_kategori']);
        if (Category::where('slug', $slug)->where('id_kategori', '!=', $id)->exists()) {
            return back()->with('error', 'Kategori dengan nama itu sudah ada.');
        }

        Category::unguarded(fn () => $kategori->update(['nama_kategori' => $data['nama_kategori'], 'slug' => $slug]));

        return back()->with('status', 'Kategori diperbarui.');
    }

    public function categoryDestroy(int $id)
    {
        $kategori = Category::findOrFail($id);

        // Cegah hapus kategori yang masih berisi produk (relasinya cascade, produknya ikut hilang)
        if (Product::where('id_kategori', $id)->exists()) {
            return back()->with('error', 'Kategori masih berisi produk. Pindahkan atau hapus produknya dulu.');
        }

        $kategori->delete();

        return back()->with('status', "Kategori \"{$kategori->nama_kategori}\" dihapus.");
    }

    public function orders()
    {
        $orders = Order::with(['items', 'tracking'])->orderByDesc('id_order')->get()->map(fn ($o) => $o->tampil())->all();

        return view('admin.orders.index', ['orders' => $orders]);
    }

    public function orderShow(string $kode)
    {
        $order = Order::with(['items', 'tracking'])->where('kode', $kode)->first();
        abort_if(! $order, 404);

        return view('admin.orders.show', ['order' => $order->tampil(), 'statuses' => DummyData::STATUS]);
    }

    /** Verifikasi pembayaran (hanya Transfer yang masih Menunggu Verifikasi). */
    public function verify(string $kode)
    {
        $order = Order::where('kode', $kode)->firstOrFail();

        if ($order->metode_pembayaran !== 'Transfer' || $order->status_pesanan !== 'Menunggu Verifikasi') {
            return back()->with('error', 'Pesanan ini tidak perlu diverifikasi.');
        }

        $order->ubahStatus('Diproses', 'Pembayaran terverifikasi. Pesanan sedang dikemas oleh penjual.');

        return back()->with('status', "Pembayaran {$order->kode} diverifikasi. Status: Diproses.");
    }

    /** Update status pengiriman. */
    public function updateStatus(Request $request, string $kode)
    {
        $data = $request->validate(['status' => ['required', 'in:Diproses,Dikirim,Selesai']], [
            'status.required' => 'Pilih status.', 'status.in' => 'Status tidak valid.',
        ]);

        $order = Order::where('kode', $kode)->firstOrFail();

        if ($order->status_pesanan === 'Menunggu Verifikasi') {
            return back()->with('error', 'Verifikasi pembayaran dulu sebelum mengubah status pengiriman.');
        }
        if ($order->status_pesanan !== $data['status']) {
            $order->ubahStatus($data['status']);
        }

        return back()->with('status', "Status {$order->kode} diubah menjadi \"{$data['status']}\".");
    }

    /** Laporan 7 hari terakhir dari tabel orders. */
    public function reports()
    {
        $perTanggal = Order::with('items')->where('tanggal_order', '>=', now()->subDays(6)->toDateString())
            ->get()->groupBy('tanggal_order');

        $laporan = [];
        for ($i = 6; $i >= 0; $i--) {
            $tgl = now()->subDays($i)->toDateString();
            $g = $perTanggal->get($tgl, collect());
            $laporan[] = [
                'tanggal'    => $tgl,
                'pesanan'    => $g->count(),
                'barang'     => (int) $g->flatMap(fn ($o) => $o->items)->sum('jumlah_beli'),
                'pendapatan' => (int) $g->sum('total_harga'),
            ];
        }

        return view('admin.reports', [
            'laporan' => $laporan,
            'total'   => collect($laporan)->sum('pendapatan'),
            'max'     => max(1, collect($laporan)->max('pendapatan')),
        ]);
    }
}
