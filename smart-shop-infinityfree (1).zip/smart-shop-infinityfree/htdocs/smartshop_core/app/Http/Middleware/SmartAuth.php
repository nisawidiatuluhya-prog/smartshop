<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/**
 * Penjaga halaman berdasarkan role. Dipakai di routes: SmartAuth::class.':Admin'
 */
class SmartAuth
{
    public function handle(Request $request, Closure $next, string $role)
    {
        $user = $request->session()->get('smartshop.user');

        if ($user && $user['role'] === $role) {
            return $next($request);
        }

        if ($role === 'Admin') {
            return redirect()->route('admin.login')
                ->with('error', $user ? 'Halaman ini khusus admin.' : 'Silakan masuk sebagai admin dulu.');
        }

        $request->session()->put('url.intended', $request->fullUrl());

        return redirect()->route('login')
            ->with('error', $user ? 'Masuk sebagai pelanggan untuk melanjutkan.' : 'Silakan masuk atau daftar dulu untuk checkout.');
    }
}
