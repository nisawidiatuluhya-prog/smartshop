<?php

namespace App\Providers;

use App\Support\Catalog;
use App\Support\DummyData;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Memuat helper rupiah() tanpa perlu mengubah composer.json
        require_once app_path('Support/helpers.php');
    }

    public function boot(): void
    {
        // Waktu Indonesia (WIB) supaya tanggal pesanan dan laporan harian tepat
        config(['app.timezone' => 'Asia/Jakarta']);
        date_default_timezone_set('Asia/Jakarta');

        // Data global untuk layout customer (menu kategori + katalog untuk JavaScript)
        View::composer('layouts.app', function ($view) {
            // Tiap produk dibawakan HTML gambar kecilnya (dipakai keranjang, AI widget, dll.)
            $products = array_map(fn ($p) => $p + [
                'thumb' => Blade::render('<x-product-image :product="$p" class="h-full w-full" />', ['p' => $p]),
            ], Catalog::products());

            $view->with('navCategories', Catalog::categories())
                 ->with('ssData', [
                     'products'   => $products,
                     'categories' => Catalog::categories(),
                     'couriers'   => DummyData::couriers(),
                     'rekening'   => DummyData::REKENING,
                 ]);
        });
    }
}
