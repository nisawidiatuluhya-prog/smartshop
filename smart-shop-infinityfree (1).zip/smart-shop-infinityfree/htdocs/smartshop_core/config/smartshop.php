<?php

return [
    // Akun admin: hanya satu. Ganti lewat file .env jika perlu:
    // SMARTSHOP_ADMIN_EMAIL=... dan SMARTSHOP_ADMIN_PASSWORD=...
    'admin_email'    => env('SMARTSHOP_ADMIN_EMAIL', 'admin@smartshop.test'),
    'admin_password' => env('SMARTSHOP_ADMIN_PASSWORD', 'SmartAdmin#2026'),
];
