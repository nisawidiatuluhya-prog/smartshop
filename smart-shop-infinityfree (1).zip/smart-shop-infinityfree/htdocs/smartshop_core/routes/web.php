<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ShopController;
use App\Http\Middleware\SmartAuth;
use Illuminate\Support\Facades\Route;

// ---------- Publik ----------
Route::get('/', [ShopController::class, 'home'])->name('home');
Route::get('/shop', [ShopController::class, 'index'])->name('shop');
Route::get('/produk/{slug}', [ShopController::class, 'show'])->name('produk.show');
Route::get('/keranjang', [CartController::class, 'cart'])->name('keranjang');

// ---------- Login / daftar pelanggan ----------
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.attempt');
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->name('register.store');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// ---------- Khusus pelanggan yang sudah masuk ----------
Route::middleware(SmartAuth::class.':Customer')->group(function () {
    Route::get('/checkout', [CartController::class, 'checkout'])->name('checkout');
    Route::post('/checkout', [OrderController::class, 'store'])->name('checkout.store');
    Route::get('/pesanan', [OrderController::class, 'index'])->name('pesanan.index');
});

// Pelacakan: pelanggan hanya pesanannya sendiri, admin boleh semua (dicek di controller)
Route::get('/pesanan/{kode}', [OrderController::class, 'show'])->where('kode', '[A-Za-z0-9\-]+')->name('pesanan.show');

// ---------- Admin ----------
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/login', [AuthController::class, 'showAdminLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'adminLogin'])->name('login.attempt');

    Route::middleware(SmartAuth::class.':Admin')->group(function () {
        Route::get('/', [AdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/produk', [AdminController::class, 'products'])->name('produk');
        Route::get('/produk/tambah', [AdminController::class, 'productForm'])->name('produk.tambah');
        Route::get('/produk/{id}/edit', [AdminController::class, 'productForm'])->whereNumber('id')->name('produk.edit');
        Route::get('/kategori', [AdminController::class, 'categories'])->name('kategori');
        Route::post('/produk', [AdminController::class, 'productStore'])->name('produk.simpan');
        Route::put('/produk/{id}', [AdminController::class, 'productUpdate'])->whereNumber('id')->name('produk.ubah');
        Route::delete('/produk/{id}', [AdminController::class, 'productDestroy'])->whereNumber('id')->name('produk.hapus');
        Route::post('/kategori', [AdminController::class, 'categoryStore'])->name('kategori.simpan');
        Route::put('/kategori/{id}', [AdminController::class, 'categoryUpdate'])->whereNumber('id')->name('kategori.ubah');
        Route::delete('/kategori/{id}', [AdminController::class, 'categoryDestroy'])->whereNumber('id')->name('kategori.hapus');
        Route::get('/pesanan', [AdminController::class, 'orders'])->name('pesanan');
        Route::get('/pesanan/{kode}', [AdminController::class, 'orderShow'])->name('pesanan.show');
        Route::post('/pesanan/{kode}/verifikasi', [AdminController::class, 'verify'])->name('pesanan.verifikasi');
        Route::post('/pesanan/{kode}/status', [AdminController::class, 'updateStatus'])->name('pesanan.status');
        Route::get('/laporan', [AdminController::class, 'reports'])->name('laporan');
    });
});
